
/*
  # Auto-create profile and user_settings on signup

  ## Problem
  The "Database error saving new user" occurs because:
  1. Supabase Auth creates a record in auth.users
  2. The app tries to insert into public.profiles from the client
  3. RLS blocks this because the JWT is not yet fully propagated, or
     the insert races against the session being established

  ## Solution
  Add a PostgreSQL trigger on auth.users that automatically creates:
  - A row in public.profiles with defaults
  - A row in public.user_settings with defaults

  This runs with SECURITY DEFINER (elevated privileges) so RLS never
  blocks it. The client-side code no longer needs to insert profiles.

  ## Changes
  1. New function: handle_new_user() - runs on auth.users INSERT
  2. New trigger: on_auth_user_created - calls handle_new_user()
  3. Both profiles and user_settings are created atomically

  ## Security
  - Function runs as postgres (SECURITY DEFINER) to bypass RLS
  - Existing RLS policies on profiles and user_settings are unchanged
  - Users can still read/update their own rows per existing policies
*/

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, username, display_name, avatar_url, bio, credits, is_premium, age_verified)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'name', NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
    NULL,
    '',
    100,
    false,
    false
  )
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO public.user_settings (id)
  VALUES (NEW.id)
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();
