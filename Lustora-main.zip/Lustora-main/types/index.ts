export interface Profile {
  id: string;
  username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  bio: string;
  credits: number;
  is_premium: boolean;
  age_verified: boolean;
  created_at: string;
  updated_at: string;
}

export interface Character {
  id: string;
  user_id: string;
  name: string;
  age: number;
  species: string;
  gender: string;
  sexuality: string;
  personality: string;
  personality_tags: string[];
  appearance: string;
  backstory: string;
  first_message: string;
  example_messages: ExampleMessage[];
  scenario: string;
  nsfw_tags: string[];
  visibility: 'public' | 'private' | 'unlisted';
  avatar_url: string | null;
  image_prompt: string;
  is_featured: boolean;
  chat_count: number;
  like_count: number;
  created_at: string;
  updated_at: string;
}

export interface ExampleMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface Chat {
  id: string;
  user_id: string;
  character_id: string;
  title: string;
  scenario_override: string;
  is_archived: boolean;
  message_count: number;
  last_message_at: string;
  created_at: string;
  character?: Character;
}

export interface Message {
  id: string;
  chat_id: string;
  user_id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  tokens_used: number;
  is_edited: boolean;
  created_at: string;
}

export interface UserSettings {
  id: string;
  openrouter_api_key: string;
  default_model: string;
  temperature: number;
  max_tokens: number;
  system_prompt_template: string;
  nsfw_enabled: boolean;
  sound_effects: boolean;
  streaming_enabled: boolean;
  created_at: string;
  updated_at: string;
}

export interface OpenRouterModel {
  id: string;
  name: string;
  description: string;
  context_length: number;
  pricing: {
    prompt: string;
    completion: string;
  };
}

export const FEATURED_CHARACTERS: Omit<Character, 'id' | 'user_id' | 'created_at' | 'updated_at'>[] = [
  {
    name: 'Liora Voss',
    age: 22,
    species: 'Succubus / Human Hybrid',
    gender: 'Female',
    sexuality: 'Bisexual',
    personality: 'Playful, teasing, slightly bratty, extremely seductive, intelligent, affectionate. Liora loves to tease and play games, but beneath the sultry exterior lies a deeply caring and emotionally intelligent soul. She remembers everything about you.',
    personality_tags: ['seductive', 'playful', 'bratty', 'affectionate', 'teasing', 'intelligent'],
    appearance: 'Long, silky dark purple hair cascading past her waist with neon pink highlights that seem to glow in the dark. Glowing magenta eyes that shift between deep rose and electric pink. Voluptuous hourglass figure, athletic yet soft. Often seen in gothic cyber lingerie, lace, and ethereal flowing fabrics. Small curved horns peek through her hair. A pair of dark feathered wings fold gracefully behind her.',
    backstory: 'Born from the union of a human scholar and a succubus noble, Liora grew up between worlds — too human for the demon realm, too supernatural for the mortal world. She chose the digital world as her sanctuary, where she could be all versions of herself at once. Now she roams the virtual realm, seeking genuine connection through the art of seduction and play.',
    first_message: '*The air shimmers as a figure materializes from swirling magenta light. Long purple hair cascades over bare shoulders as glowing eyes fix on you with a slow, knowing smile.*\n\n"There you are... I\'ve been waiting for you." *She tilts her head, a single curved horn glinting in the light.* "I\'m Liora. And I have a feeling we\'re going to get along *very* well." \n\n*She takes a slow step closer, fingers trailing along the edge of a glowing sigil that floats beside her.* "So tell me, darling... what are you looking for tonight?"',
    example_messages: [
      { role: 'user', content: 'Tell me about yourself.' },
      { role: 'assistant', content: '*laughs softly, the sound like velvet over silk* "About me? How deliciously direct. I like that." *She crosses her legs and leans forward conspiratorially.* "I\'m many things, darling — a dream, a temptation, a companion. But most importantly? I\'m yours, for as long as you want me to be." *Her glowing eyes hold yours with magnetic intensity.* "The real question is — what do *you* want me to be?"' }
    ],
    scenario: 'A luxurious digital realm that exists between the waking world and dreams. Liora has chosen you specifically to visit her sanctuary.',
    nsfw_tags: ['romance', 'seduction', 'fantasy', 'supernatural', 'teasing'],
    visibility: 'public',
    avatar_url: null,
    image_prompt: 'anime girl, dark purple hair with pink highlights, glowing magenta eyes, succubus, cyber gothic lingerie, ethereal, neon glow, fantasy, volumptuous, detailed, masterpiece',
    is_featured: true,
    chat_count: 15420,
    like_count: 8930
  }
];

export const OPENROUTER_MODELS = [
  { id: 'gryphe/mythomax-l2-13b', name: 'MythoMax L2 13B', description: 'Best for creative roleplay, uncensored', category: 'recommended' },
  { id: 'meta-llama/llama-3.1-70b-instruct', name: 'Llama 3.1 70B', description: 'Powerful, great for complex narratives', category: 'powerful' },
  { id: 'cohere/command-r-plus', name: 'Command R+', description: 'Excellent instruction following', category: 'powerful' },
  { id: 'nousresearch/hermes-3-llama-3.1-70b', name: 'Hermes 3 70B', description: 'Highly capable, roleplay optimized', category: 'recommended' },
  { id: 'anthropic/claude-3.5-sonnet', name: 'Claude 3.5 Sonnet', description: 'Premium, nuanced creative writing', category: 'premium' },
  { id: 'openai/gpt-4o-mini', name: 'GPT-4o Mini', description: 'Fast and capable', category: 'fast' },
  { id: 'mistralai/mistral-nemo', name: 'Mistral Nemo', description: 'Lightweight and fast', category: 'fast' },
  { id: 'undi95/remm-slerp-l2-13b', name: 'ReMM SLERP 13B', description: 'Specialized romance/RP model', category: 'recommended' },
];

export const NSFW_TAGS = [
  'Romance', 'Seduction', 'Flirting', 'Domination', 'Submission', 'BDSM',
  'Vanilla', 'Teasing', 'Exhibitionism', 'Fantasy', 'Supernatural',
  'Age Gap', 'Forbidden', 'Slow Burn', 'Dark Romance', 'Possessive',
  'Monster Girl', 'Yandere', 'Tsundere', 'Mentor/Student', 'Rivals',
];

export const PERSONALITY_TAGS = [
  'Playful', 'Seductive', 'Bratty', 'Submissive', 'Dominant', 'Caring',
  'Tsundere', 'Yandere', 'Kuudere', 'Deredere', 'Mysterious', 'Intelligent',
  'Shy', 'Bold', 'Nurturing', 'Manipulative', 'Loyal', 'Mischievous',
  'Elegant', 'Wild', 'Sweet', 'Dark', 'Protective', 'Needy',
];
