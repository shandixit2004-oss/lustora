'use client';

import Link from 'next/link';
import { Sparkles, Menu, X } from 'lucide-react';
import { useState } from 'react';
import AgeGate from '@/components/AgeGate';
import Hero from '@/components/landing/Hero';
import Features from '@/components/landing/Features';
import CharacterCarousel from '@/components/landing/CharacterCarousel';
import Testimonials from '@/components/landing/Testimonials';
import Footer from '@/components/landing/Footer';

function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/5">
      <div className="container mx-auto px-4 lg:px-8 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg gradient-magenta flex items-center justify-center text-white font-black text-sm animate-pulse-glow">
            L
          </div>
          <span className="text-xl font-black gradient-text">Lustora</span>
        </Link>

        <div className="hidden md:flex items-center gap-6">
          <Link href="/discover" className="text-gray-400 hover:text-pink-400 text-sm transition-colors">Discover</Link>
          <Link href="/signup" className="text-gray-400 hover:text-pink-400 text-sm transition-colors">Characters</Link>
          <Link href="/signup" className="text-gray-400 hover:text-pink-400 text-sm transition-colors">Pricing</Link>
        </div>

        <div className="hidden md:flex items-center gap-3">
          <Link href="/login" className="text-gray-300 hover:text-white text-sm px-4 py-2 rounded-lg hover:bg-white/5 transition-all">
            Sign In
          </Link>
          <Link href="/signup" className="btn-primary text-sm px-5 py-2.5 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            Get Started Free
          </Link>
        </div>

        <button className="md:hidden text-gray-400 hover:text-white" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {menuOpen && (
        <div className="md:hidden glass border-t border-white/5 px-4 py-4 space-y-3">
          <Link href="/discover" className="block text-gray-300 py-2 hover:text-pink-400 transition-colors">Discover</Link>
          <Link href="/login" className="block text-gray-300 py-2 hover:text-pink-400 transition-colors">Sign In</Link>
          <Link href="/signup" className="btn-primary block text-center py-3">Get Started Free</Link>
        </div>
      )}
    </nav>
  );
}

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-[#050505]">
      <AgeGate />
      <Navbar />
      <Hero />
      <Features />
      <CharacterCarousel />
      <Testimonials />

      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0"
            style={{ background: 'radial-gradient(ellipse at center, rgba(192,38,211,0.08) 0%, transparent 60%)' }} />
        </div>
        <div className="container mx-auto px-4 lg:px-8 text-center relative z-10">
          <div className="max-w-3xl mx-auto glass-card rounded-3xl p-12">
            <div className="w-16 h-16 mx-auto rounded-2xl gradient-magenta flex items-center justify-center mb-6 animate-pulse-glow">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-4xl md:text-5xl font-black mb-4">
              <span className="gradient-text">Start Your Story</span>
              <br />
              <span className="text-white">Tonight</span>
            </h2>
            <p className="text-gray-400 text-lg mb-8 max-w-xl mx-auto">
              Join 50,000+ users already exploring their deepest fantasies with AI companions that feel real.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/signup" className="btn-primary flex items-center gap-2 text-lg px-8 py-4 w-full sm:w-auto justify-center">
                <Sparkles className="w-5 h-5" />
                Create Free Account
              </Link>
              <Link href="/login" className="btn-secondary flex items-center gap-2 text-lg px-8 py-4 w-full sm:w-auto justify-center">
                Sign In
              </Link>
            </div>
            <p className="text-gray-600 text-xs mt-6">
              Free to start. No credit card required. Must be 18+.
            </p>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
