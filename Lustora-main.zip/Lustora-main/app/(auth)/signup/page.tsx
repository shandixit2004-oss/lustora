'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Eye, EyeOff, Sparkles, Mail, Lock, User, CircleAlert as AlertCircle, CircleCheck as CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

export default function SignupPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [ageConfirmed, setAgeConfirmed] = useState(false);

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault();
    if (!ageConfirmed) { setError('You must confirm you are 18 or older.'); return; }
    if (password.length < 6) { setError('Password must be at least 6 characters.'); return; }
    setError('');
    setLoading(true);
    try {
      const derivedUsername = username.trim() || email.split('@')[0];
      const { data, error: signUpError } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          data: {
            username: derivedUsername,
            name: derivedUsername,
          },
        },
      });
      if (signUpError) {
        if (signUpError.message.includes('already registered') || signUpError.message.includes('already been registered')) {
          throw new Error('An account with this email already exists. Try signing in.');
        }
        throw signUpError;
      }
      if (data.user) {
        setSuccess(true);
        setTimeout(() => router.push('/dashboard'), 1500);
      }
    } catch (err: unknown) {
      const e = err as Error;
      setError(e.message || 'Could not create account. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  const passwordStrength = password.length === 0 ? 0 : password.length < 6 ? 1 : password.length < 10 ? 2 : 3;
  const strengthColors = ['', '#EF4444', '#F97316', '#22C55E'];
  const strengthLabels = ['', 'Weak', 'Medium', 'Strong'];

  return (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center relative overflow-hidden p-4">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/3 right-1/4 w-96 h-96 rounded-full opacity-10"
          style={{ background: 'radial-gradient(circle, #C026D3, transparent 70%)', filter: 'blur(60px)' }} />
        <div className="absolute bottom-1/3 left-1/4 w-80 h-80 rounded-full opacity-10"
          style={{ background: 'radial-gradient(circle, #22D3EE, transparent 70%)', filter: 'blur(60px)' }} />
        {[...Array(20)].map((_, i) => (
          <div key={i} className="absolute rounded-full opacity-20"
            style={{
              width: Math.random() * 3 + 1 + 'px',
              height: Math.random() * 3 + 1 + 'px',
              background: ['#C026D3', '#F472B6', '#22D3EE'][i % 3],
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              animation: `particle-rise ${Math.random() * 12 + 8}s linear infinite`,
              animationDelay: Math.random() * 6 + 's',
            }} />
        ))}
      </div>

      <div className="w-full max-w-md relative z-10 animate-zoom-in">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 rounded-xl gradient-magenta flex items-center justify-center text-white font-black text-lg animate-pulse-glow">
              L
            </div>
            <span className="text-3xl font-black gradient-text">Lustora</span>
          </Link>
          <h1 className="text-2xl font-bold text-white mb-1">Begin your journey</h1>
          <p className="text-gray-400 text-sm">Free forever. No credit card required.</p>
        </div>

        <div className="glass-card rounded-2xl p-8">
          {success ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 mx-auto rounded-full bg-green-500/20 border border-green-500/30 flex items-center justify-center mb-4">
                <CheckCircle className="w-8 h-8 text-green-400" />
              </div>
              <h3 className="text-white font-bold text-lg mb-2">Account Created!</h3>
              <p className="text-gray-400 text-sm">Redirecting to your dashboard...</p>
              <div className="mt-4 w-8 h-8 border-2 border-pink-500/30 border-t-pink-500 rounded-full animate-spin mx-auto" />
            </div>
          ) : (
            <>
              {error && (
                <div className="flex items-center gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm mb-6">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <form onSubmit={handleSignup} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Username (optional)</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="your_username"
                      className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:border-pink-500/50 transition-colors text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="your@email.com"
                      required
                      className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:border-pink-500/50 transition-colors text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      required
                      minLength={6}
                      className="w-full pl-10 pr-12 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:border-pink-500/50 transition-colors text-sm"
                    />
                    <button type="button" onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors">
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {password.length > 0 && (
                    <div className="mt-2 flex items-center gap-2">
                      <div className="flex gap-1 flex-1">
                        {[1, 2, 3].map((level) => (
                          <div key={level} className="h-1 flex-1 rounded-full transition-colors"
                            style={{ background: passwordStrength >= level ? strengthColors[passwordStrength] : '#1f2937' }} />
                        ))}
                      </div>
                      <span className="text-xs" style={{ color: strengthColors[passwordStrength] }}>
                        {strengthLabels[passwordStrength]}
                      </span>
                    </div>
                  )}
                </div>

                <div className="flex items-start gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setAgeConfirmed(!ageConfirmed)}
                    className={`w-5 h-5 rounded shrink-0 mt-0.5 border-2 flex items-center justify-center transition-all ${
                      ageConfirmed ? 'gradient-magenta border-transparent' : 'border-gray-600 bg-transparent'
                    }`}
                  >
                    {ageConfirmed && <CheckCircle className="w-3 h-3 text-white" />}
                  </button>
                  <label className="text-gray-400 text-xs leading-relaxed cursor-pointer" onClick={() => setAgeConfirmed(!ageConfirmed)}>
                    I confirm I am <strong className="text-white">18 years of age or older</strong> and agree to the{' '}
                    <Link href="#" className="text-pink-400 hover:underline">Terms of Service</Link> and{' '}
                    <Link href="#" className="text-pink-400 hover:underline">Privacy Policy</Link>.
                  </label>
                </div>

                <button
                  type="submit"
                  disabled={loading || !ageConfirmed}
                  className="btn-primary w-full flex items-center justify-center gap-2 py-3.5 mt-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      Create Account — It's Free
                    </>
                  )}
                </button>
              </form>

              <p className="text-center text-gray-400 text-sm mt-6">
                Already have an account?{' '}
                <Link href="/login" className="text-pink-400 hover:text-pink-300 font-semibold transition-colors">
                  Sign in
                </Link>
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
