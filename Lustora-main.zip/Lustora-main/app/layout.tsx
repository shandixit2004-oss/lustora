import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });

export const metadata: Metadata = {
  title: 'Lustora — Bring Your Fantasies to Life',
  description: 'Premium AI Roleplay platform. Create, discover, and chat with seductive AI characters. Uncensored, immersive, and deeply personal.',
  keywords: ['AI roleplay', 'character AI', 'adult AI chat', 'fantasy roleplay'],
  robots: { index: false, follow: false },
  viewport: 'width=device-width, initial-scale=1',
  themeColor: '#C026D3',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.variable} font-sans antialiased bg-[#050505] text-gray-100`}>
        {children}
      </body>
    </html>
  );
}
