import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { messages, model, temperature, max_tokens, api_key, system_prompt } = body;

    if (!api_key) {
      return NextResponse.json({ error: 'OpenRouter API key required. Add it in Settings.' }, { status: 401 });
    }

    const openRouterMessages = system_prompt
      ? [{ role: 'system', content: system_prompt }, ...messages]
      : messages;

    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${api_key}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': process.env.NEXT_PUBLIC_APP_URL || 'https://lustora.ai',
        'X-Title': 'Lustora AI Roleplay',
      },
      body: JSON.stringify({
        model: model || 'gryphe/mythomax-l2-13b',
        messages: openRouterMessages,
        temperature: temperature || 0.9,
        max_tokens: max_tokens || 500,
        stream: false,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      return NextResponse.json(
        { error: errorData.error?.message || `OpenRouter API error: ${response.status}` },
        { status: response.status }
      );
    }

    const data = await response.json();
    return NextResponse.json(data);
  } catch (error) {
    console.error('Chat API error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
