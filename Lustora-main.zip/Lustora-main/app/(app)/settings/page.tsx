'use client';

import { useEffect, useState } from 'react';
import { Key, Save, Eye, EyeOff, CircleCheck as CheckCircle, CircleAlert as AlertCircle, Zap, FileSliders as Sliders, ExternalLink, Copy, Check } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { UserSettings, OPENROUTER_MODELS } from '@/types';

export default function SettingsPage() {
  const [settings, setSettings] = useState<Partial<UserSettings>>({
    openrouter_api_key: '',
    default_model: 'gryphe/mythomax-l2-13b',
    temperature: 0.9,
    max_tokens: 500,
    system_prompt_template: '',
    nsfw_enabled: true,
    sound_effects: false,
    streaming_enabled: true,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [showKey, setShowKey] = useState(false);
  const [testResult, setTestResult] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [testError, setTestError] = useState('');
  const [activeTab, setActiveTab] = useState('api');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase.from('user_settings').select('*').eq('id', user.id).maybeSingle();
      if (data) setSettings(data);
      setLoading(false);
    }
    load();
  }, []);

  async function handleSave() {
    setSaving(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    await supabase.from('user_settings').upsert({ id: user.id, ...settings, updated_at: new Date().toISOString() });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
    setSaving(false);
  }

  async function testApiKey() {
    if (!settings.openrouter_api_key) return;
    setTestResult('testing');
    setTestError('');
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{ role: 'user', content: 'Say "API key valid" and nothing else.' }],
          model: settings.default_model,
          temperature: 0.1,
          max_tokens: 20,
          api_key: settings.openrouter_api_key,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Test failed');
      setTestResult('success');
    } catch (err: unknown) {
      const e = err as Error;
      setTestResult('error');
      setTestError(e.message || 'Connection failed');
    }
  }

  const maskedKey = settings.openrouter_api_key
    ? showKey ? settings.openrouter_api_key : settings.openrouter_api_key.slice(0, 8) + '••••••••••••••••••••••••' + settings.openrouter_api_key.slice(-4)
    : '';

  return (
    <div className="min-h-screen p-4 lg:p-8">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-black text-white mb-2">
            <span className="gradient-text">Settings</span>
          </h1>
          <p className="text-gray-400">Configure your AI and experience preferences.</p>
        </div>

        <div className="flex gap-2 mb-6">
          {[
            { id: 'api', label: 'API & Models', icon: Key },
            { id: 'generation', label: 'Generation', icon: Sliders },
            { id: 'account', label: 'Account', icon: Zap },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  activeTab === tab.id ? 'gradient-magenta text-white' : 'glass-card text-gray-400 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {activeTab === 'api' && (
          <div className="space-y-4">
            <div className="glass-card rounded-2xl p-6">
              <h2 className="text-white font-bold mb-4 flex items-center gap-2">
                <Key className="w-4 h-4 text-pink-400" />
                OpenRouter API Key
              </h2>

              <div className="p-4 rounded-xl mb-5"
                style={{ background: 'rgba(192,38,211,0.05)', border: '1px solid rgba(192,38,211,0.15)' }}>
                <p className="text-gray-300 text-sm mb-3">
                  Lustora uses <strong className="text-pink-400">OpenRouter</strong> to power AI conversations.
                  Get your free API key at openrouter.ai — it gives you access to 100+ models including
                  MythoMax, Llama 3.1, Claude, and more.
                </p>
                <a
                  href="https://openrouter.ai/keys"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-pink-400 hover:text-pink-300 text-sm font-semibold transition-colors"
                >
                  Get your free API key
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">API Key</label>
                  <div className="relative flex gap-2">
                    <div className="flex-1 relative">
                      <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                      <input
                        type={showKey ? 'text' : 'password'}
                        value={settings.openrouter_api_key || ''}
                        onChange={(e) => setSettings((s) => ({ ...s, openrouter_api_key: e.target.value }))}
                        placeholder="sk-or-v1-..."
                        className="w-full pl-10 pr-12 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:border-pink-500/50 transition-colors text-sm font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowKey(!showKey)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
                      >
                        {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <button
                      onClick={testApiKey}
                      disabled={!settings.openrouter_api_key || testResult === 'testing'}
                      className="px-4 py-2 rounded-xl text-sm font-medium glass border border-white/10 text-gray-300 hover:text-white hover:border-pink-500/30 transition-all disabled:opacity-40"
                    >
                      {testResult === 'testing' ? (
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : 'Test'}
                    </button>
                  </div>
                  <p className="text-gray-600 text-xs mt-1">
                    Your key is stored locally and never shared. Only used for API calls.
                  </p>
                </div>

                {testResult === 'success' && (
                  <div className="flex items-center gap-2 p-3 rounded-xl bg-green-500/10 border border-green-500/20 text-green-400 text-sm">
                    <CheckCircle className="w-4 h-4" />
                    API key is valid and working!
                  </div>
                )}
                {testResult === 'error' && (
                  <div className="flex items-center gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
                    <AlertCircle className="w-4 h-4" />
                    {testError || 'API key test failed. Check your key and try again.'}
                  </div>
                )}
              </div>
            </div>

            <div className="glass-card rounded-2xl p-6">
              <h2 className="text-white font-bold mb-4">Default Model</h2>
              <div className="space-y-2">
                {OPENROUTER_MODELS.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setSettings((s) => ({ ...s, default_model: m.id }))}
                    className={`w-full text-left p-4 rounded-xl transition-all flex items-center justify-between ${
                      settings.default_model === m.id
                        ? 'border-glow text-white'
                        : 'glass border border-white/5 text-gray-400 hover:text-white hover:border-white/10'
                    }`}
                  >
                    <div>
                      <div className={`font-semibold text-sm ${settings.default_model === m.id ? 'text-white' : ''}`}>{m.name}</div>
                      <div className="text-xs text-gray-500 mt-0.5">{m.description}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        m.category === 'recommended' ? 'bg-pink-500/20 text-pink-400' :
                        m.category === 'premium' ? 'bg-yellow-500/20 text-yellow-400' :
                        m.category === 'fast' ? 'bg-cyan-500/20 text-cyan-400' :
                        'bg-gray-500/20 text-gray-400'
                      }`}>
                        {m.category}
                      </span>
                      {settings.default_model === m.id && (
                        <div className="w-4 h-4 rounded-full gradient-magenta flex items-center justify-center">
                          <Check className="w-2.5 h-2.5 text-white" />
                        </div>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'generation' && (
          <div className="glass-card rounded-2xl p-6 space-y-6">
            <h2 className="text-white font-bold">Generation Defaults</h2>

            <div>
              <div className="flex justify-between mb-3">
                <div>
                  <label className="text-sm font-medium text-gray-300">Temperature</label>
                  <p className="text-gray-500 text-xs">Higher = more creative & unpredictable responses</p>
                </div>
                <span className="text-pink-400 font-mono text-lg font-bold">{settings.temperature}</span>
              </div>
              <input
                type="range" min="0.1" max="2.0" step="0.05"
                value={settings.temperature || 0.9}
                onChange={(e) => setSettings((s) => ({ ...s, temperature: parseFloat(e.target.value) }))}
                className="w-full accent-pink-500"
              />
              <div className="flex justify-between text-xs text-gray-600 mt-1">
                <span>0.1 — Precise</span><span>0.9 — Balanced</span><span>2.0 — Wild</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-3">
                <div>
                  <label className="text-sm font-medium text-gray-300">Max Tokens</label>
                  <p className="text-gray-500 text-xs">Maximum length of AI responses</p>
                </div>
                <span className="text-pink-400 font-mono text-lg font-bold">{settings.max_tokens}</span>
              </div>
              <input
                type="range" min="100" max="2000" step="50"
                value={settings.max_tokens || 500}
                onChange={(e) => setSettings((s) => ({ ...s, max_tokens: parseInt(e.target.value) }))}
                className="w-full accent-pink-500"
              />
              <div className="flex justify-between text-xs text-gray-600 mt-1">
                <span>100 — Short</span><span>500 — Medium</span><span>2000 — Long</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">System Prompt Template</label>
              <p className="text-gray-500 text-xs mb-2">
                Added to every conversation. Use <code className="text-pink-400 bg-pink-500/10 px-1 rounded">{'{{char}}'}</code> and <code className="text-pink-400 bg-pink-500/10 px-1 rounded">{'{{user}}'}</code>.
              </p>
              <textarea
                value={settings.system_prompt_template || ''}
                onChange={(e) => setSettings((s) => ({ ...s, system_prompt_template: e.target.value }))}
                rows={4}
                placeholder="Additional system instructions added to every conversation..."
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:border-pink-500/50 transition-colors text-sm resize-none"
              />
            </div>

            <div className="space-y-3">
              <h3 className="text-sm font-medium text-gray-300">Preferences</h3>
              {[
                { key: 'nsfw_enabled', label: 'NSFW Content', desc: 'Allow explicit adult content in responses' },
                { key: 'sound_effects', label: 'Sound Effects', desc: 'Play subtle sounds during chat' },
              ].map((pref) => (
                <div key={pref.key} className="flex items-center justify-between p-3 rounded-xl glass border border-white/5">
                  <div>
                    <div className="text-white text-sm font-medium">{pref.label}</div>
                    <div className="text-gray-500 text-xs">{pref.desc}</div>
                  </div>
                  <button
                    onClick={() => setSettings((s) => ({ ...s, [pref.key]: !s[pref.key as keyof typeof s] }))}
                    className={`w-12 h-6 rounded-full transition-all relative ${
                      settings[pref.key as keyof typeof settings] ? 'bg-pink-500' : 'bg-gray-700'
                    }`}
                  >
                    <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${
                      settings[pref.key as keyof typeof settings] ? 'left-[26px]' : 'left-0.5'
                    }`} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'account' && (
          <div className="glass-card rounded-2xl p-6 space-y-4">
            <h2 className="text-white font-bold">Account</h2>
            <div className="p-4 rounded-xl"
              style={{ background: 'rgba(192,38,211,0.05)', border: '1px solid rgba(192,38,211,0.15)' }}>
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl gradient-magenta flex items-center justify-center text-white font-bold text-lg">
                  U
                </div>
                <div>
                  <div className="text-white font-semibold">Free Account</div>
                  <div className="text-gray-400 text-sm">100 credits / day</div>
                </div>
              </div>
              <button className="w-full py-3 rounded-xl gradient-magenta text-white font-semibold text-sm hover:opacity-90 transition-opacity">
                Upgrade to Premium — Unlimited
              </button>
            </div>
          </div>
        )}

        <div className="mt-6 flex justify-end">
          <button
            onClick={handleSave}
            disabled={saving}
            className="btn-primary flex items-center gap-2 px-8 py-3 disabled:opacity-50"
          >
            {saving ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : saved ? (
              <><CheckCircle className="w-4 h-4" /> Saved!</>
            ) : (
              <><Save className="w-4 h-4" /> Save Settings</>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
