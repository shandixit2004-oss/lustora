'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Sparkles, CirclePlus as PlusCircle, MessageCircle, Clock, ChevronRight, Compass, Flame } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Character, Chat, Profile } from '@/types';

const MOCK_CHARS: Partial<Character>[] = [
  { id: '1', name: 'Liora Voss', species: 'Succubus', age: 22, personality_tags: ['Seductive', 'Playful'], chat_count: 15420, like_count: 8930, is_featured: true, visibility: 'public' },
  { id: '2', name: 'Aria Chen', species: 'Human', age: 24, personality_tags: ['Dominant', 'Tsundere'], chat_count: 12100, like_count: 7200, is_featured: false, visibility: 'public' },
  { id: '3', name: 'Nova Blackwood', species: 'Angel', age: 20, personality_tags: ['Romantic', 'Dark'], chat_count: 9800, like_count: 6400, is_featured: false, visibility: 'public' },
  { id: '4', name: 'Sakura Himura', species: 'Human', age: 19, personality_tags: ['Shy', 'Sweet'], chat_count: 18300, like_count: 11200, is_featured: false, visibility: 'public' },
];

const GREETINGS = [
  "Welcome back, darling~ I've been thinking about you.",
  "Oh, you're here! I knew you'd come back to me.",
  "Finally... I was starting to miss you terribly.",
  "Back so soon? Not that I'm complaining, of course~",
];

export default function DashboardPage() {
  const router = useRouter();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [recentChats, setRecentChats] = useState<Chat[]>([]);
  const [greeting] = useState(GREETINGS[Math.floor(Math.random() * GREETINGS.length)]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data: profileData } = await supabase.from('profiles').select('*').eq('id', user.id).maybeSingle();
      if (profileData) setProfile(profileData);
      const { data: chatsData } = await supabase
        .from('chats')
        .select('*, character:characters(*)')
        .eq('user_id', user.id)
        .order('last_message_at', { ascending: false })
        .limit(4);
      if (chatsData) setRecentChats(chatsData);
      setLoading(false);
    }
    load();
  }, []);

  async function startNewChat(characterId: string) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { data: chat } = await supabase.from('chats').insert({
      user_id: user.id,
      character_id: characterId,
      title: 'New Roleplay',
    }).select().single();
    if (chat) router.push(`/chat/${chat.id}`);
  }

  const displayName = profile?.display_name || profile?.username || 'Stranger';
  const hour = new Date().getHours();
  const timeGreet = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  return (
    <div className="min-h-screen p-4 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="glass-card rounded-2xl p-6 relative overflow-hidden">
          <div className="absolute inset-0 pointer-events-none"
            style={{ background: 'radial-gradient(ellipse at 80% 50%, rgba(192,38,211,0.08) 0%, transparent 60%)' }} />
          <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <p className="text-gray-500 text-sm mb-1">{timeGreet},</p>
              <h1 className="text-2xl font-black text-white">{displayName} <span className="gradient-text">✦</span></h1>
              <div className="flex items-center gap-2 mt-2">
                <div className="w-7 h-7 rounded-full gradient-magenta flex items-center justify-center text-xs font-bold text-white">L</div>
                <p className="text-pink-300 text-sm italic">"{greeting}"</p>
              </div>
            </div>
            <div className="flex gap-3">
              <Link href="/characters/create" className="btn-primary flex items-center gap-2 text-sm px-4 py-2.5">
                <PlusCircle className="w-4 h-4" />
                Create Character
              </Link>
              <Link href="/discover" className="btn-secondary flex items-center gap-2 text-sm px-4 py-2.5">
                <Compass className="w-4 h-4" />
                Discover
              </Link>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { label: 'Total Chats', value: recentChats.length || '0', icon: MessageCircle, color: '#C026D3' },
            { label: 'Characters', value: '0', icon: Sparkles, color: '#22D3EE' },
            { label: 'Credits Left', value: '100', icon: Flame, color: '#F97316' },
            { label: 'Active Today', value: '1', icon: Clock, color: '#22C55E' },
          ].map((stat) => {
            const Icon = stat.icon;
            return (
              <div key={stat.label} className="glass-card rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{ background: `${stat.color}15`, border: `1px solid ${stat.color}20` }}>
                    <Icon className="w-4 h-4" style={{ color: stat.color }} />
                  </div>
                </div>
                <div className="text-2xl font-black text-white">{stat.value}</div>
                <div className="text-gray-500 text-xs">{stat.label}</div>
              </div>
            );
          })}
        </div>

        {recentChats.length > 0 && (
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-pink-400" />
                Continue Roleplays
              </h2>
              <Link href="/chats" className="text-pink-400 hover:text-pink-300 text-sm flex items-center gap-1 transition-colors">
                View all <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {recentChats.map((chat) => (
                <Link key={chat.id} href={`/chat/${chat.id}`}
                  className="glass-card rounded-xl p-4 flex items-center gap-3 hover:border-pink-500/20 transition-all group">
                  <div className="w-10 h-10 rounded-xl gradient-magenta flex items-center justify-center text-white font-bold text-sm shrink-0">
                    {chat.character?.name?.[0] || '?'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-white font-semibold text-sm truncate">{chat.character?.name || 'Unknown'}</div>
                    <div className="text-gray-500 text-xs truncate">{chat.title}</div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-600 group-hover:text-pink-400 transition-colors shrink-0" />
                </Link>
              ))}
            </div>
          </section>
        )}

        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Flame className="w-4 h-4 text-orange-400" />
              Trending Characters
            </h2>
            <Link href="/discover" className="text-pink-400 hover:text-pink-300 text-sm flex items-center gap-1 transition-colors">
              View all <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {MOCK_CHARS.map((char) => (
              <div key={char.id} className="character-card glass-card rounded-2xl overflow-hidden cursor-pointer border border-white/5 hover:border-pink-500/20">
                <div className="relative h-40"
                  style={{ background: 'linear-gradient(160deg, #1a0525 0%, #0d0118 50%, #050505 100%)' }}>
                  <div className="absolute inset-0"
                    style={{ background: 'radial-gradient(circle at 50% 30%, rgba(192,38,211,0.25) 0%, transparent 60%)' }} />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full border-2 border-pink-500/40 flex items-center justify-center"
                      style={{ background: 'linear-gradient(135deg, #2d0845, #1a0530)', boxShadow: '0 0 20px rgba(192,38,211,0.4)' }}>
                      <span className="text-2xl font-black text-pink-400">{char.name?.[0]}</span>
                    </div>
                  </div>
                  {char.is_featured && (
                    <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-full gradient-magenta text-white text-xs">
                      <Sparkles className="w-2.5 h-2.5" />
                      Featured
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <h3 className="text-white font-bold text-sm mb-0.5">{char.name}</h3>
                  <p className="text-pink-400 text-xs mb-2">{char.species} • {char.age}</p>
                  <div className="flex flex-wrap gap-1 mb-3">
                    {char.personality_tags?.slice(0, 2).map((tag) => (
                      <span key={tag} className="px-1.5 py-0.5 rounded text-xs"
                        style={{ background: 'rgba(192,38,211,0.15)', color: '#F472B6', border: '1px solid rgba(192,38,211,0.2)' }}>
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500 flex items-center gap-1">
                      <MessageCircle className="w-3 h-3" />
                      {char.chat_count?.toLocaleString()}
                    </span>
                    <button
                      onClick={() => char.id && startNewChat(char.id)}
                      className="text-xs font-semibold px-3 py-1.5 rounded-lg gradient-magenta text-white hover:opacity-90 transition-opacity"
                    >
                      Chat
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="glass-card rounded-2xl p-6 relative overflow-hidden">
          <div className="absolute inset-0 pointer-events-none"
            style={{ background: 'radial-gradient(ellipse at 20% 50%, rgba(34,211,238,0.05) 0%, transparent 50%)' }} />
          <div className="relative z-10 flex flex-col sm:flex-row items-center gap-6">
            <div className="w-16 h-16 rounded-2xl gradient-magenta flex items-center justify-center text-white font-black text-2xl shrink-0 animate-pulse-glow">
              +
            </div>
            <div className="text-center sm:text-left">
              <h3 className="text-white font-bold text-lg mb-1">Create Your Perfect Companion</h3>
              <p className="text-gray-400 text-sm">Design every detail — appearance, personality, kinks, backstory. Make them truly yours.</p>
            </div>
            <Link href="/characters/create" className="btn-primary flex items-center gap-2 text-sm px-6 py-3 shrink-0 sm:ml-auto">
              <PlusCircle className="w-4 h-4" />
              Create Now
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
