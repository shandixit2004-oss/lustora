'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Plus, Sparkles, MessageCircle, CreditCard as Edit, Trash2, Eye, EyeOff, Lock } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Character } from '@/types';

export default function CharactersPage() {
  const router = useRouter();
  const [characters, setCharacters] = useState<Character[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase
        .from('characters')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      if (data) setCharacters(data);
      setLoading(false);
    }
    load();
  }, []);

  async function deleteChar(id: string, e: React.MouseEvent) {
    e.stopPropagation();
    if (!confirm('Delete this character? This cannot be undone.')) return;
    await supabase.from('characters').delete().eq('id', id);
    setCharacters((prev) => prev.filter((c) => c.id !== id));
  }

  async function startChat(characterId: string, e: React.MouseEvent) {
    e.stopPropagation();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { data: chat } = await supabase.from('chats').insert({
      user_id: user.id, character_id: characterId, title: 'New Roleplay',
    }).select().single();
    if (chat) router.push(`/chat/${chat.id}`);
  }

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-pink-500/30 border-t-pink-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 lg:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-black text-white mb-1">
              My <span className="gradient-text">Characters</span>
            </h1>
            <p className="text-gray-400 text-sm">{characters.length} character{characters.length !== 1 ? 's' : ''} created</p>
          </div>
          <Link href="/characters/create" className="btn-primary flex items-center gap-2 text-sm px-4 py-2.5">
            <Plus className="w-4 h-4" />
            Create New
          </Link>
        </div>

        {characters.length === 0 ? (
          <div className="text-center py-24">
            <div className="w-20 h-20 mx-auto rounded-2xl glass-card flex items-center justify-center mb-6">
              <Sparkles className="w-10 h-10 text-gray-700" />
            </div>
            <h3 className="text-white font-bold text-lg mb-2">No characters yet</h3>
            <p className="text-gray-500 mb-6">Create your first AI companion. Give them a name, personality, and story.</p>
            <Link href="/characters/create" className="btn-primary inline-flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Create First Character
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {characters.map((char) => (
              <div key={char.id} className="character-card glass-card rounded-2xl overflow-hidden border border-white/5 hover:border-pink-500/20 group">
                <div className="relative h-44"
                  style={{ background: 'linear-gradient(160deg, #1a0525 0%, #0d0118 50%, #050505 100%)' }}>
                  <div className="absolute inset-0"
                    style={{ background: 'radial-gradient(circle at 50% 30%, rgba(192,38,211,0.2) 0%, transparent 60%)' }} />

                  {char.avatar_url ? (
                    <img src={char.avatar_url} alt={char.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-16 h-16 rounded-full border-2 border-pink-500/40 flex items-center justify-center"
                        style={{ background: 'linear-gradient(135deg, #2d0845, #1a0530)', boxShadow: '0 0 20px rgba(192,38,211,0.4)' }}>
                        <span className="text-2xl font-black text-pink-400">{char.name[0]}</span>
                      </div>
                    </div>
                  )}

                  <div className="absolute top-2 right-2 flex items-center gap-1.5">
                    {char.visibility === 'public' ? (
                      <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-xs"
                        style={{ background: 'rgba(34,197,94,0.15)', color: '#22C55E', border: '1px solid rgba(34,197,94,0.2)' }}>
                        <Eye className="w-2.5 h-2.5" />
                        Public
                      </span>
                    ) : char.visibility === 'unlisted' ? (
                      <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-xs"
                        style={{ background: 'rgba(234,179,8,0.15)', color: '#EAB308', border: '1px solid rgba(234,179,8,0.2)' }}>
                        <EyeOff className="w-2.5 h-2.5" />
                        Unlisted
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-xs"
                        style={{ background: 'rgba(107,114,128,0.15)', color: '#9CA3AF', border: '1px solid rgba(107,114,128,0.2)' }}>
                        <Lock className="w-2.5 h-2.5" />
                        Private
                      </span>
                    )}
                  </div>

                  <div className="absolute bottom-0 left-0 right-0 h-12"
                    style={{ background: 'linear-gradient(to top, rgba(5,5,5,0.95), transparent)' }} />
                </div>

                <div className="p-4">
                  <h3 className="text-white font-bold mb-0.5">{char.name}</h3>
                  <p className="text-pink-400 text-xs mb-2">{char.species} • {char.gender} • {char.age}</p>

                  <div className="flex flex-wrap gap-1 mb-3">
                    {char.personality_tags?.slice(0, 3).map((tag) => (
                      <span key={tag} className="px-1.5 py-0.5 rounded text-xs"
                        style={{ background: 'rgba(192,38,211,0.15)', color: '#F472B6', border: '1px solid rgba(192,38,211,0.2)' }}>
                        {tag}
                      </span>
                    ))}
                    {(!char.personality_tags || char.personality_tags.length === 0) && (
                      <span className="text-gray-600 text-xs">No tags</span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => startChat(char.id, e)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl gradient-magenta text-white text-xs font-semibold hover:opacity-90 transition-opacity"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      Chat
                    </button>
                    <Link
                      href={`/characters/create?edit=${char.id}`}
                      onClick={(e) => e.stopPropagation()}
                      className="p-2 rounded-xl glass border border-white/10 text-gray-400 hover:text-white hover:border-pink-500/30 transition-all"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </Link>
                    <button
                      onClick={(e) => deleteChar(char.id, e)}
                      className="p-2 rounded-xl glass border border-white/10 text-gray-400 hover:text-red-400 hover:border-red-500/30 transition-all"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
