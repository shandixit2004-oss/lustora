'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Save, Sparkles, ChevronDown, ChevronUp, Image, Info, Eye, EyeOff } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { NSFW_TAGS, PERSONALITY_TAGS } from '@/types';

const GENDERS = ['Female', 'Male', 'Non-binary', 'Genderfluid', 'Any'];
const SEXUALITIES = ['Heterosexual', 'Homosexual', 'Bisexual', 'Pansexual', 'Omnisexual', 'Any'];
const SPECIES = ['Human', 'Elf', 'Vampire', 'Werewolf', 'Succubus', 'Angel', 'Demon', 'Witch', 'Android', 'Alien', 'Other'];

export default function CreateCharacterPage() {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [activeSection, setActiveSection] = useState('basic');

  const [form, setForm] = useState({
    name: '',
    age: '21',
    species: 'Human',
    gender: 'Female',
    sexuality: 'Bisexual',
    personality: '',
    personality_tags: [] as string[],
    appearance: '',
    backstory: '',
    first_message: '',
    example_messages: [{ role: 'user', content: '' }, { role: 'assistant', content: '' }] as { role: string; content: string }[],
    scenario: '',
    nsfw_tags: [] as string[],
    visibility: 'private' as 'public' | 'private' | 'unlisted',
    image_prompt: '',
  });

  function update(key: keyof typeof form, value: unknown) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function toggleTag(arr: string[], tag: string, key: 'personality_tags' | 'nsfw_tags') {
    const newArr = arr.includes(tag) ? arr.filter((t) => t !== tag) : [...arr, tag];
    update(key, newArr);
  }

  async function handleSave() {
    if (!form.name.trim()) { setError('Character name is required.'); return; }
    if (!form.first_message.trim()) { setError('First message is required.'); return; }
    setSaving(true);
    setError('');
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');
      const { data, error: insertError } = await supabase.from('characters').insert({
        user_id: user.id,
        name: form.name,
        age: parseInt(form.age) || 21,
        species: form.species,
        gender: form.gender,
        sexuality: form.sexuality,
        personality: form.personality,
        personality_tags: form.personality_tags,
        appearance: form.appearance,
        backstory: form.backstory,
        first_message: form.first_message,
        example_messages: form.example_messages.filter((m) => m.content.trim()),
        scenario: form.scenario,
        nsfw_tags: form.nsfw_tags,
        visibility: form.visibility,
        image_prompt: form.image_prompt,
      }).select().single();
      if (insertError) throw insertError;
      router.push(`/characters`);
    } catch (err: unknown) {
      const e = err as Error;
      setError(e.message || 'Failed to create character');
    } finally {
      setSaving(false);
    }
  }

  const sections = [
    { id: 'basic', label: 'Basic Info' },
    { id: 'personality', label: 'Personality' },
    { id: 'appearance', label: 'Appearance' },
    { id: 'story', label: 'Story & Messages' },
    { id: 'nsfw', label: 'NSFW & Settings' },
  ];

  const isComplete = form.name && form.first_message;

  return (
    <div className="min-h-screen p-4 lg:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-black text-white mb-2">
            Create <span className="gradient-text">Character</span>
          </h1>
          <p className="text-gray-400">Design your perfect AI companion in detail.</p>
        </div>

        {error && (
          <div className="mb-6 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
            {error}
          </div>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <div className="flex gap-2 flex-wrap">
              {sections.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setActiveSection(s.id)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                    activeSection === s.id
                      ? 'gradient-magenta text-white'
                      : 'glass-card text-gray-400 hover:text-white'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>

            {activeSection === 'basic' && (
              <div className="glass-card rounded-2xl p-6 space-y-5">
                <h2 className="text-white font-bold text-lg">Basic Information</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Character Name *</label>
                    <input
                      value={form.name}
                      onChange={(e) => update('name', e.target.value)}
                      placeholder="e.g. Aria Blackwood"
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:border-pink-500/50 transition-colors text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Age</label>
                    <input
                      type="number"
                      min="18"
                      max="999"
                      value={form.age}
                      onChange={(e) => update('age', e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:border-pink-500/50 transition-colors text-sm"
                    />
                    <p className="text-gray-600 text-xs mt-1">All characters must be 18+</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Species / Race</label>
                    <select
                      value={form.species}
                      onChange={(e) => update('species', e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-[#0f0f0f] border border-white/10 text-white focus:border-pink-500/50 transition-colors text-sm"
                    >
                      {SPECIES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Gender</label>
                    <select
                      value={form.gender}
                      onChange={(e) => update('gender', e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-[#0f0f0f] border border-white/10 text-white focus:border-pink-500/50 transition-colors text-sm"
                    >
                      {GENDERS.map((g) => <option key={g} value={g}>{g}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Sexuality</label>
                    <select
                      value={form.sexuality}
                      onChange={(e) => update('sexuality', e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-[#0f0f0f] border border-white/10 text-white focus:border-pink-500/50 transition-colors text-sm"
                    >
                      {SEXUALITIES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'personality' && (
              <div className="glass-card rounded-2xl p-6 space-y-5">
                <h2 className="text-white font-bold text-lg">Personality</h2>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Personality Description</label>
                  <p className="text-gray-500 text-xs mb-2">
                    Use <code className="text-pink-400 bg-pink-500/10 px-1 rounded">{'{{char}}'}</code> for the character's name and <code className="text-pink-400 bg-pink-500/10 px-1 rounded">{'{{user}}'}</code> for the user.
                  </p>
                  <textarea
                    value={form.personality}
                    onChange={(e) => update('personality', e.target.value)}
                    rows={5}
                    placeholder="Describe {'{{char}}'}'s personality in detail. How do they speak? What are their quirks? What drives them?"
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:border-pink-500/50 transition-colors text-sm resize-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-3">Personality Tags</label>
                  <div className="flex flex-wrap gap-2">
                    {PERSONALITY_TAGS.map((tag) => (
                      <button
                        key={tag}
                        onClick={() => toggleTag(form.personality_tags, tag, 'personality_tags')}
                        className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                          form.personality_tags.includes(tag)
                            ? 'gradient-magenta text-white'
                            : 'bg-white/5 text-gray-400 hover:text-white border border-white/10'
                        }`}
                      >
                        {tag}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'appearance' && (
              <div className="glass-card rounded-2xl p-6 space-y-5">
                <h2 className="text-white font-bold text-lg">Appearance</h2>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Physical Description</label>
                  <textarea
                    value={form.appearance}
                    onChange={(e) => update('appearance', e.target.value)}
                    rows={4}
                    placeholder="Describe her appearance in vivid detail — hair, eyes, body, clothing, any unique features..."
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:border-pink-500/50 transition-colors text-sm resize-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center gap-2">
                    <Image className="w-4 h-4 text-pink-400" />
                    AI Image Generation Prompt
                  </label>
                  <textarea
                    value={form.image_prompt}
                    onChange={(e) => update('image_prompt', e.target.value)}
                    rows={3}
                    placeholder="anime girl, long purple hair, glowing pink eyes, succubus, gothic lingerie, detailed, masterpiece..."
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:border-pink-500/50 transition-colors text-sm resize-none"
                  />
                  <button className="mt-2 flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-gray-400 hover:text-pink-400 glass border border-white/10 hover:border-pink-500/30 transition-all">
                    <Sparkles className="w-4 h-4" />
                    Generate Avatar (Coming Soon)
                  </button>
                </div>
              </div>
            )}

            {activeSection === 'story' && (
              <div className="glass-card rounded-2xl p-6 space-y-5">
                <h2 className="text-white font-bold text-lg">Story & Messages</h2>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Backstory / Lore</label>
                  <textarea
                    value={form.backstory}
                    onChange={(e) => update('backstory', e.target.value)}
                    rows={4}
                    placeholder="What is {'{{char}}'}'s history? What shaped them into who they are today?"
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:border-pink-500/50 transition-colors text-sm resize-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Scenario / World Setting</label>
                  <textarea
                    value={form.scenario}
                    onChange={(e) => update('scenario', e.target.value)}
                    rows={3}
                    placeholder="Describe the world or situation where your roleplay takes place..."
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:border-pink-500/50 transition-colors text-sm resize-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    First Message * <span className="text-gray-500 font-normal text-xs">(This is how {'{{char}}'} opens the conversation)</span>
                  </label>
                  <textarea
                    value={form.first_message}
                    onChange={(e) => update('first_message', e.target.value)}
                    rows={5}
                    placeholder="*She turns to look at you with glowing eyes*&#10;&#10;&quot;Well, well... a new face. I'm {'{{char}}'}. And you must be {'{{user}}'}. I've been expecting someone interesting.&quot;"
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:border-pink-500/50 transition-colors text-sm resize-none"
                  />
                  <p className="text-gray-600 text-xs mt-1">Use *asterisks* for actions. Include dialogue in quotes.</p>
                </div>
              </div>
            )}

            {activeSection === 'nsfw' && (
              <div className="glass-card rounded-2xl p-6 space-y-5">
                <h2 className="text-white font-bold text-lg">NSFW & Settings</h2>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-3">Content Tags</label>
                  <div className="flex flex-wrap gap-2">
                    {NSFW_TAGS.map((tag) => (
                      <button
                        key={tag}
                        onClick={() => toggleTag(form.nsfw_tags, tag, 'nsfw_tags')}
                        className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                          form.nsfw_tags.includes(tag)
                            ? 'gradient-magenta text-white'
                            : 'bg-white/5 text-gray-400 hover:text-white border border-white/10'
                        }`}
                      >
                        {tag}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-3">Visibility</label>
                  <div className="grid grid-cols-3 gap-3">
                    {(['public', 'unlisted', 'private'] as const).map((v) => (
                      <button
                        key={v}
                        onClick={() => update('visibility', v)}
                        className={`p-3 rounded-xl text-sm font-medium text-center transition-all flex flex-col items-center gap-1 ${
                          form.visibility === v
                            ? 'gradient-magenta text-white'
                            : 'glass-card text-gray-400 hover:text-white'
                        }`}
                      >
                        {v === 'public' ? <Eye className="w-4 h-4" /> : v === 'private' ? <EyeOff className="w-4 h-4" /> : <Sparkles className="w-4 h-4" />}
                        <span className="capitalize">{v}</span>
                      </button>
                    ))}
                  </div>
                  <p className="text-gray-500 text-xs mt-2">
                    Public = anyone can find it. Unlisted = link only. Private = only you.
                  </p>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div className="glass-card rounded-2xl p-5 sticky top-24">
              <h3 className="text-white font-bold mb-4 flex items-center gap-2">
                <Info className="w-4 h-4 text-pink-400" />
                Preview
              </h3>
              <div className="rounded-xl overflow-hidden mb-4"
                style={{ background: 'linear-gradient(160deg, #1a0525, #0d0118)', height: '200px' }}>
                <div className="w-full h-full flex flex-col items-center justify-center gap-2">
                  <div className="w-16 h-16 rounded-full border-2 border-pink-500/40 flex items-center justify-center"
                    style={{ background: 'linear-gradient(135deg, #2d0845, #1a0530)', boxShadow: '0 0 20px rgba(192,38,211,0.4)' }}>
                    <span className="text-2xl font-black text-pink-400">
                      {form.name?.[0] || '?'}
                    </span>
                  </div>
                  <div className="text-center">
                    <p className="text-white font-bold text-sm">{form.name || 'Character Name'}</p>
                    <p className="text-pink-400 text-xs">{form.species} • {form.age}</p>
                  </div>
                </div>
              </div>

              <div className="space-y-2 text-xs mb-4">
                <div className="flex justify-between">
                  <span className="text-gray-500">Gender</span>
                  <span className="text-white">{form.gender}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Sexuality</span>
                  <span className="text-white">{form.sexuality}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Tags</span>
                  <span className="text-pink-400">{form.personality_tags.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">First Message</span>
                  <span className={form.first_message ? 'text-green-400' : 'text-red-400'}>
                    {form.first_message ? 'Set ✓' : 'Required'}
                  </span>
                </div>
              </div>

              {form.personality_tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mb-4">
                  {form.personality_tags.slice(0, 5).map((t) => (
                    <span key={t} className="px-1.5 py-0.5 rounded text-xs"
                      style={{ background: 'rgba(192,38,211,0.15)', color: '#F472B6' }}>
                      {t}
                    </span>
                  ))}
                </div>
              )}

              {form.first_message && (
                <div className="rounded-xl p-3 mb-4 text-xs text-gray-300 italic leading-relaxed"
                  style={{ background: 'rgba(192,38,211,0.05)', border: '1px solid rgba(192,38,211,0.1)' }}>
                  "{form.first_message.slice(0, 120)}{form.first_message.length > 120 ? '...' : ''}"
                </div>
              )}

              <button
                onClick={handleSave}
                disabled={saving || !isComplete}
                className="btn-primary w-full flex items-center justify-center gap-2 py-3 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {saving ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Save Character
                  </>
                )}
              </button>
              {!isComplete && (
                <p className="text-gray-600 text-xs text-center mt-2">Name and first message required</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
