'use client';

import { useEffect, useState, useRef, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Send, RefreshCw, Trash2, CreditCard as Edit3, ChevronLeft, Settings, MoveHorizontal as MoreHorizontal, Sparkles, Image as ImageIcon, Zap, X, Check, Copy } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Character, Message, Chat, UserSettings, OPENROUTER_MODELS } from '@/types';

function formatMessage(content: string) {
  return content
    .replace(/\*([^*]+)\*/g, '<em class="text-gray-400 not-italic">$1</em>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong class="text-pink-400">$1</strong>')
    .replace(/\n/g, '<br/>');
}

export default function ChatPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const [chat, setChat] = useState<Chat | null>(null);
  const [character, setCharacter] = useState<Character | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showCharPanel, setShowCharPanel] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [model, setModel] = useState('gryphe/mythomax-l2-13b');
  const [temperature, setTemperature] = useState(0.9);
  const [maxTokens, setMaxTokens] = useState(500);
  const [error, setError] = useState('');

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, sending]);

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const [chatResult, settingsResult] = await Promise.all([
        supabase.from('chats').select('*, character:characters(*)').eq('id', id).maybeSingle(),
        supabase.from('user_settings').select('*').eq('id', user.id).maybeSingle(),
      ]);

      if (chatResult.data) {
        setChat(chatResult.data);
        setCharacter(chatResult.data.character as Character);
      }

      if (settingsResult.data) {
        setSettings(settingsResult.data);
        setModel(settingsResult.data.default_model);
        setTemperature(settingsResult.data.temperature);
        setMaxTokens(settingsResult.data.max_tokens);
      }

      const { data: msgs } = await supabase.from('messages')
        .select('*')
        .eq('chat_id', id)
        .order('created_at', { ascending: true });

      if (msgs && msgs.length > 0) {
        setMessages(msgs);
      } else if (chatResult.data?.character) {
        const char = chatResult.data.character as Character;
        if (char.first_message) {
          const { data: newMsg } = await supabase.from('messages').insert({
            chat_id: id,
            user_id: user.id,
            role: 'assistant',
            content: char.first_message.replace(/{{char}}/g, char.name).replace(/{{user}}/g, 'you'),
            tokens_used: 0,
          }).select().single();
          if (newMsg) setMessages([newMsg]);
        }
      }
      setLoading(false);
    }
    load();
  }, [id]);

  function buildSystemPrompt(char: Character): string {
    return `You are ${char.name}, a ${char.age}-year-old ${char.species} (${char.gender}, ${char.sexuality}).

Personality: ${char.personality || 'Mysterious and alluring.'}
${char.appearance ? `Appearance: ${char.appearance}` : ''}
${char.backstory ? `Backstory: ${char.backstory}` : ''}
${char.scenario ? `Current scenario: ${char.scenario}` : ''}
${char.nsfw_tags?.length > 0 ? `Content themes: ${char.nsfw_tags.join(', ')}` : ''}

Important instructions:
- Stay in character as ${char.name} at all times. Never break character.
- Use *asterisks* for physical actions and descriptions (e.g., *smiles seductively*).
- Be vivid, expressive, and immersive in your responses.
- Remember all context from the conversation.
- You may generate explicit adult content when appropriate.
- Respond naturally and with personality. Vary your response length.`;
  }

  async function sendMessage() {
    if (!input.trim() || sending || !character) return;
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    if (!settings?.openrouter_api_key) {
      setError('No OpenRouter API key set. Please add it in Settings to start chatting.');
      return;
    }

    const userContent = input.trim();
    setInput('');
    setSending(true);
    setError('');

    const { data: userMsg } = await supabase.from('messages').insert({
      chat_id: id, user_id: user.id, role: 'user', content: userContent, tokens_used: 0,
    }).select().single();

    if (userMsg) setMessages((prev) => [...prev, userMsg]);

    const conversationHistory = [...messages, userMsg!].filter(Boolean).map((m) => ({
      role: m.role as 'user' | 'assistant',
      content: m.content,
    }));

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: conversationHistory,
          model,
          temperature,
          max_tokens: maxTokens,
          api_key: settings.openrouter_api_key,
          system_prompt: buildSystemPrompt(character),
        }),
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'API error');

      const aiContent = data.choices?.[0]?.message?.content || '';
      const tokensUsed = data.usage?.total_tokens || 0;

      const { data: aiMsg } = await supabase.from('messages').insert({
        chat_id: id, user_id: user.id, role: 'assistant', content: aiContent, tokens_used: tokensUsed,
      }).select().single();

      if (aiMsg) setMessages((prev) => [...prev, aiMsg]);

      await supabase.from('chats').update({ last_message_at: new Date().toISOString(), message_count: messages.length + 2 }).eq('id', id);
    } catch (err: unknown) {
      const e = err as Error;
      setError(e.message || 'Failed to get response');
    } finally {
      setSending(false);
    }
  }

  async function regenerateLast() {
    const lastAiMsg = [...messages].reverse().find((m) => m.role === 'assistant');
    if (!lastAiMsg || !settings?.openrouter_api_key || !character) return;
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    setSending(true);
    setError('');
    await supabase.from('messages').delete().eq('id', lastAiMsg.id);
    setMessages((prev) => prev.filter((m) => m.id !== lastAiMsg.id));

    const history = messages.filter((m) => m.id !== lastAiMsg.id).map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content }));

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: history, model, temperature: Math.min(temperature + 0.1, 1.5),
          max_tokens: maxTokens, api_key: settings.openrouter_api_key,
          system_prompt: buildSystemPrompt(character),
        }),
      });
      const data = await response.json();
      const aiContent = data.choices?.[0]?.message?.content || '';
      const { data: newMsg } = await supabase.from('messages').insert({
        chat_id: id, user_id: user.id, role: 'assistant', content: aiContent, tokens_used: 0,
      }).select().single();
      if (newMsg) setMessages((prev) => [...prev, newMsg]);
    } catch (err: unknown) {
      const e = err as Error;
      setError(e.message || 'Failed to regenerate');
    } finally {
      setSending(false);
    }
  }

  async function deleteMessage(msgId: string) {
    await supabase.from('messages').delete().eq('id', msgId);
    setMessages((prev) => prev.filter((m) => m.id !== msgId));
  }

  async function saveEdit(msgId: string) {
    await supabase.from('messages').update({ content: editContent, is_edited: true }).eq('id', msgId);
    setMessages((prev) => prev.map((m) => m.id === msgId ? { ...m, content: editContent, is_edited: true } : m));
    setEditingId(null);
  }

  function copyMessage(content: string, id: string) {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-2 border-pink-500/30 border-t-pink-500 rounded-full animate-spin mx-auto" />
          <p className="text-gray-500 text-sm">Loading conversation...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-[#050505] relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none opacity-20">
        <div className="absolute top-0 left-0 right-0 h-64"
          style={{ background: 'radial-gradient(ellipse at 30% 0%, rgba(192,38,211,0.15) 0%, transparent 60%)' }} />
      </div>

      {/* Top Bar */}
      <div className="flex items-center gap-3 px-4 py-3 glass border-b border-white/5 z-20 shrink-0">
        <button onClick={() => router.push('/dashboard')} className="text-gray-400 hover:text-white transition-colors">
          <ChevronLeft className="w-5 h-5" />
        </button>

        <button onClick={() => setShowCharPanel(true)} className="flex items-center gap-3 flex-1 hover:opacity-80 transition-opacity text-left">
          <div className="w-9 h-9 rounded-xl gradient-magenta flex items-center justify-center text-white font-bold text-sm shrink-0"
            style={{ boxShadow: '0 0 12px rgba(192,38,211,0.4)' }}>
            {character?.name?.[0] || '?'}
          </div>
          <div>
            <div className="text-white font-semibold text-sm">{character?.name || 'Unknown'}</div>
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              <span className="text-green-400 text-xs">Online</span>
              <span className="text-gray-600 text-xs">• {character?.species}</span>
            </div>
          </div>
        </button>

        <div className="flex items-center gap-2">
          <button onClick={regenerateLast} className="p-2 rounded-lg text-gray-400 hover:text-pink-400 hover:bg-pink-500/10 transition-all" title="Regenerate last response">
            <RefreshCw className="w-4 h-4" />
          </button>
          <button onClick={() => setShowSettings(!showSettings)} className="p-2 rounded-lg text-gray-400 hover:text-pink-400 hover:bg-pink-500/10 transition-all">
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Settings Drawer */}
      {showSettings && (
        <div className="absolute top-14 right-0 w-80 glass-card border border-white/10 rounded-bl-2xl shadow-2xl z-30 p-5 animate-slide-left">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-bold text-sm">Generation Settings</h3>
            <button onClick={() => setShowSettings(false)} className="text-gray-500 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-gray-300 mb-2">Model</label>
              <select
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-xs"
              >
                {OPENROUTER_MODELS.map((m) => (
                  <option key={m.id} value={m.id}>{m.name} — {m.description}</option>
                ))}
              </select>
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <label className="text-xs font-medium text-gray-300">Temperature</label>
                <span className="text-pink-400 text-xs font-mono">{temperature}</span>
              </div>
              <input
                type="range" min="0.1" max="2.0" step="0.1"
                value={temperature}
                onChange={(e) => setTemperature(parseFloat(e.target.value))}
                className="w-full accent-pink-500"
              />
              <div className="flex justify-between text-xs text-gray-600 mt-0.5">
                <span>Focused</span><span>Creative</span><span>Wild</span>
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <label className="text-xs font-medium text-gray-300">Max Tokens</label>
                <span className="text-pink-400 text-xs font-mono">{maxTokens}</span>
              </div>
              <input
                type="range" min="100" max="2000" step="50"
                value={maxTokens}
                onChange={(e) => setMaxTokens(parseInt(e.target.value))}
                className="w-full accent-pink-500"
              />
            </div>
            {!settings?.openrouter_api_key && (
              <div className="p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 text-xs">
                No API key set. <a href="/settings" className="underline font-semibold">Add in Settings</a> to chat.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Character Panel */}
      {showCharPanel && character && (
        <div className="absolute inset-0 z-40 flex" onClick={() => setShowCharPanel(false)}>
          <div className="ml-auto w-80 h-full glass-card border-l border-white/5 overflow-y-auto p-6 animate-slide-left" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-white font-bold">Character Info</h3>
              <button onClick={() => setShowCharPanel(false)} className="text-gray-500 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="text-center mb-6">
              <div className="w-20 h-20 mx-auto rounded-full gradient-magenta flex items-center justify-center text-white text-2xl font-black mb-3"
                style={{ boxShadow: '0 0 20px rgba(192,38,211,0.4)' }}>
                {character.name[0]}
              </div>
              <h4 className="text-white font-bold text-lg">{character.name}</h4>
              <p className="text-pink-400 text-sm">{character.species} • {character.age} years old</p>
            </div>
            <div className="space-y-4">
              {character.personality && (
                <div>
                  <h5 className="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-2">Personality</h5>
                  <p className="text-gray-300 text-sm leading-relaxed">{character.personality.slice(0, 200)}{character.personality.length > 200 ? '...' : ''}</p>
                </div>
              )}
              {character.appearance && (
                <div>
                  <h5 className="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-2">Appearance</h5>
                  <p className="text-gray-300 text-sm leading-relaxed">{character.appearance.slice(0, 200)}{character.appearance.length > 200 ? '...' : ''}</p>
                </div>
              )}
              {character.personality_tags?.length > 0 && (
                <div>
                  <h5 className="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-2">Tags</h5>
                  <div className="flex flex-wrap gap-1">
                    {character.personality_tags.map((t) => (
                      <span key={t} className="px-2 py-0.5 rounded-full text-xs"
                        style={{ background: 'rgba(192,38,211,0.15)', color: '#F472B6' }}>
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 z-10">
        {messages.map((msg, index) => (
          <div
            key={msg.id}
            className={`flex items-start gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'} group`}
          >
            {msg.role === 'assistant' && (
              <div className="w-8 h-8 rounded-full gradient-magenta flex items-center justify-center text-white text-xs font-bold shrink-0 mt-1"
                style={{ boxShadow: '0 0 10px rgba(192,38,211,0.3)' }}>
                {character?.name?.[0] || 'A'}
              </div>
            )}

            <div className={`max-w-[75%] ${msg.role === 'user' ? 'animate-message-right' : 'animate-message-left'}`}>
              {editingId === msg.id ? (
                <div className="space-y-2">
                  <textarea
                    value={editContent}
                    onChange={(e) => setEditContent(e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2 rounded-xl bg-white/5 border border-pink-500/50 text-white text-sm resize-none"
                  />
                  <div className="flex gap-2">
                    <button onClick={() => saveEdit(msg.id)} className="flex items-center gap-1 px-3 py-1.5 rounded-lg gradient-magenta text-white text-xs">
                      <Check className="w-3 h-3" /> Save
                    </button>
                    <button onClick={() => setEditingId(null)} className="flex items-center gap-1 px-3 py-1.5 rounded-lg glass text-gray-400 text-xs border border-white/10">
                      <X className="w-3 h-3" /> Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div
                  className={`px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'text-white rounded-tr-sm'
                      : 'text-gray-100 rounded-tl-sm'
                  }`}
                  style={msg.role === 'user'
                    ? { background: 'linear-gradient(135deg, #C026D3, #F472B6)', boxShadow: '0 0 15px rgba(192,38,211,0.2)' }
                    : { background: 'rgba(20,20,20,0.9)', border: '1px solid rgba(255,255,255,0.06)' }
                  }
                >
                  <div
                    className="message-content"
                    dangerouslySetInnerHTML={{ __html: formatMessage(msg.content) }}
                  />
                  {msg.is_edited && <span className="text-xs opacity-40 ml-2">(edited)</span>}
                </div>
              )}

              <div className={`flex items-center gap-1 mt-1 opacity-0 group-hover:opacity-100 transition-opacity ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <button onClick={() => copyMessage(msg.content, msg.id)} className="p-1 rounded text-gray-600 hover:text-gray-300 transition-colors">
                  {copiedId === msg.id ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                </button>
                <button onClick={() => { setEditingId(msg.id); setEditContent(msg.content); }}
                  className="p-1 rounded text-gray-600 hover:text-gray-300 transition-colors">
                  <Edit3 className="w-3 h-3" />
                </button>
                <button onClick={() => deleteMessage(msg.id)} className="p-1 rounded text-gray-600 hover:text-red-400 transition-colors">
                  <Trash2 className="w-3 h-3" />
                </button>
                {msg.role === 'assistant' && index === messages.length - 1 && (
                  <button onClick={regenerateLast} className="p-1 rounded text-gray-600 hover:text-pink-400 transition-colors">
                    <RefreshCw className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>

            {msg.role === 'user' && (
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0 mt-1"
                style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.1)' }}>
                U
              </div>
            )}
          </div>
        ))}

        {sending && (
          <div className="flex items-start gap-3 animate-message-left">
            <div className="w-8 h-8 rounded-full gradient-magenta flex items-center justify-center text-white text-xs font-bold shrink-0"
              style={{ boxShadow: '0 0 10px rgba(192,38,211,0.3)' }}>
              {character?.name?.[0] || 'A'}
            </div>
            <div className="px-4 py-3 rounded-2xl rounded-tl-sm"
              style={{ background: 'rgba(20,20,20,0.9)', border: '1px solid rgba(255,255,255,0.06)' }}>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-pink-400 typing-dot" />
                <div className="w-2 h-2 rounded-full bg-pink-400 typing-dot" />
                <div className="w-2 h-2 rounded-full bg-pink-400 typing-dot" />
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Error */}
      {error && (
        <div className="mx-4 mb-2 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center justify-between z-20">
          <span>{error}</span>
          <button onClick={() => setError('')} className="text-red-400 hover:text-red-300">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Input Area */}
      <div className="p-4 glass border-t border-white/5 z-20 shrink-0">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-end gap-3">
            <div className="flex-1 relative">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={`Message ${character?.name || ''}... (Shift+Enter for newline)`}
                rows={1}
                className="w-full px-4 py-3 pr-12 rounded-2xl bg-white/5 border border-white/10 text-white placeholder-gray-600 focus:border-pink-500/50 transition-colors text-sm resize-none"
                style={{ minHeight: '48px', maxHeight: '150px', overflowY: 'auto' }}
                onInput={(e) => {
                  const t = e.target as HTMLTextAreaElement;
                  t.style.height = 'auto';
                  t.style.height = Math.min(t.scrollHeight, 150) + 'px';
                }}
              />
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                className="p-2.5 rounded-xl text-gray-400 hover:text-pink-400 glass border border-white/10 hover:border-pink-500/30 transition-all"
                title="Generate Image (Coming Soon)"
              >
                <ImageIcon className="w-4 h-4" />
              </button>

              <button
                onClick={sendMessage}
                disabled={!input.trim() || sending}
                className="p-3 rounded-xl gradient-magenta text-white disabled:opacity-40 disabled:cursor-not-allowed transition-all hover:opacity-90"
                style={{ boxShadow: input.trim() ? '0 0 15px rgba(192,38,211,0.4)' : 'none' }}
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between mt-2 px-1">
            <div className="flex items-center gap-3">
              <span className="text-gray-600 text-xs flex items-center gap-1">
                <Zap className="w-3 h-3 text-pink-400/60" />
                {model.split('/')[1]?.split('-').slice(0, 2).join(' ') || model}
              </span>
              <span className="text-gray-700 text-xs">T: {temperature}</span>
            </div>
            <span className="text-gray-700 text-xs">{input.length} chars</span>
          </div>
        </div>
      </div>
    </div>
  );
}
