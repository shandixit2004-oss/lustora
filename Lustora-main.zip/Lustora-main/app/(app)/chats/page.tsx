'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { MessageCircle, Plus, Trash2, Clock, Sparkles, ChevronRight } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Chat } from '@/types';
import { formatDistanceToNow } from 'date-fns';

export default function ChatsPage() {
  const router = useRouter();
  const [chats, setChats] = useState<Chat[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase
        .from('chats')
        .select('*, character:characters(*)')
        .eq('user_id', user.id)
        .eq('is_archived', false)
        .order('last_message_at', { ascending: false });
      if (data) setChats(data);
      setLoading(false);
    }
    load();
  }, []);

  async function deleteChat(chatId: string, e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    await supabase.from('chats').delete().eq('id', chatId);
    setChats((prev) => prev.filter((c) => c.id !== chatId));
  }

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-pink-500/30 border-t-pink-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 lg:p-8">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-black text-white mb-1">
              My <span className="gradient-text">Chats</span>
            </h1>
            <p className="text-gray-400 text-sm">{chats.length} active conversation{chats.length !== 1 ? 's' : ''}</p>
          </div>
          <Link href="/discover" className="btn-primary flex items-center gap-2 text-sm px-4 py-2.5">
            <Plus className="w-4 h-4" />
            New Chat
          </Link>
        </div>

        {chats.length === 0 ? (
          <div className="text-center py-24">
            <div className="w-20 h-20 mx-auto rounded-2xl glass-card flex items-center justify-center mb-6">
              <MessageCircle className="w-10 h-10 text-gray-700" />
            </div>
            <h3 className="text-white font-bold text-lg mb-2">No conversations yet</h3>
            <p className="text-gray-500 mb-6">Start a roleplay with a character to see your chats here.</p>
            <Link href="/discover" className="btn-primary inline-flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              Find a Character
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {chats.map((chat) => (
              <Link
                key={chat.id}
                href={`/chat/${chat.id}`}
                className="glass-card rounded-2xl p-4 flex items-center gap-4 hover:border-pink-500/20 transition-all group cursor-pointer block"
              >
                <div className="w-12 h-12 rounded-xl gradient-magenta flex items-center justify-center text-white font-bold text-lg shrink-0"
                  style={{ boxShadow: '0 0 15px rgba(192,38,211,0.25)' }}>
                  {chat.character?.name?.[0] || '?'}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <h3 className="text-white font-semibold truncate">{chat.character?.name || 'Unknown Character'}</h3>
                    <span className="text-gray-600 text-xs shrink-0 ml-2 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatDistanceToNow(new Date(chat.last_message_at), { addSuffix: true })}
                    </span>
                  </div>
                  <p className="text-gray-500 text-sm truncate">{chat.title}</p>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-gray-600 text-xs">{chat.message_count} messages</span>
                    {chat.character?.species && (
                      <span className="text-gray-700 text-xs">{chat.character.species}</span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={(e) => deleteChat(chat.id, e)}
                    className="p-2 rounded-lg text-gray-600 hover:text-red-400 hover:bg-red-500/10 transition-all opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <ChevronRight className="w-4 h-4 text-gray-600 group-hover:text-pink-400 transition-colors" />
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
