'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Search, Filter, Sparkles, Flame, MessageCircle, Heart, Star } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Character } from '@/types';

const MOCK_CHARS: Partial<Character>[] = [
  { id: '1', name: 'Liora Voss', species: 'Succubus', age: 22, gender: 'Female', personality_tags: ['Seductive', 'Playful', 'Bratty'], chat_count: 15420, like_count: 8930, is_featured: true, visibility: 'public', backstory: 'Platform mascot. Born from the union of a human scholar and a succubus noble.', personality: 'Playful, teasing, extremely seductive, intelligent, affectionate.' },
  { id: '2', name: 'Aria Chen', species: 'Human', age: 24, gender: 'Female', personality_tags: ['Dominant', 'Tsundere', 'Intelligent'], chat_count: 12100, like_count: 7200, is_featured: false, visibility: 'public', backstory: 'A cold detective hiding vulnerability behind her sharp tongue.', personality: 'Sharp-tongued, dominant, secretly caring.' },
  { id: '3', name: 'Nova Blackwood', species: 'Fallen Angel', age: 20, gender: 'Female', personality_tags: ['Romantic', 'Dark', 'Obsessive'], chat_count: 9800, like_count: 6400, is_featured: false, visibility: 'public', backstory: 'Cast from heaven for loving too deeply.', personality: 'Intensely romantic, dark, obsessive.' },
  { id: '4', name: 'Sakura Himura', species: 'Human', age: 19, gender: 'Female', personality_tags: ['Shy', 'Sweet', 'Loyal'], chat_count: 18300, like_count: 11200, is_featured: false, visibility: 'public', backstory: 'Quietly brilliant and painfully shy around everyone but you.', personality: 'Shy, sweet, blooms with trust.' },
  { id: '5', name: 'Vex Darkholme', species: 'Vampire', age: 500, gender: 'Male', personality_tags: ['Dominant', 'Dark', 'Protective'], chat_count: 7600, like_count: 5100, is_featured: false, visibility: 'public', backstory: 'Ancient vampire lord captivated by mortal warmth.', personality: 'Ancient, powerful, tender beneath the darkness.' },
  { id: '6', name: 'Yuki Tanaka', species: 'Witch', age: 23, gender: 'Female', personality_tags: ['Kuudere', 'Intelligent', 'Mysterious'], chat_count: 6900, like_count: 4800, is_featured: false, visibility: 'public', backstory: 'Ice witch frozen by past betrayal, slowly melting.', personality: 'Cold exterior, warm interior, deeply loyal.' },
  { id: '7', name: 'Ryuu Katsuki', species: 'Dragon Shifter', age: 28, gender: 'Male', personality_tags: ['Dominant', 'Possessive', 'Protective'], chat_count: 5400, like_count: 3900, is_featured: false, visibility: 'public', backstory: 'Dragon who has chosen you as his treasure.', personality: 'Possessive, fierce, deeply devoted.' },
  { id: '8', name: 'Elena Moonsong', species: 'Moon Elf', age: 18, gender: 'Female', personality_tags: ['Playful', 'Mischievous', 'Wild'], chat_count: 8200, like_count: 5600, is_featured: false, visibility: 'public', backstory: 'Forest elf who has never followed rules.', personality: 'Mischievous, wild, adventurous spirit.' },
];

const CATEGORIES = ['All', 'Featured', 'Romance', 'Fantasy', 'Dominant', 'Submissive', 'Shy', 'Dark'];

export default function DiscoverPage() {
  const router = useRouter();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [userChars, setUserChars] = useState<Character[]>([]);

  useEffect(() => {
    async function load() {
      const { data } = await supabase.from('characters').select('*').eq('visibility', 'public').order('chat_count', { ascending: false }).limit(20);
      if (data && data.length > 0) setUserChars(data);
    }
    load();
  }, []);

  const allChars = [...(userChars.length > 0 ? userChars : (MOCK_CHARS as Character[]))];

  const filtered = allChars.filter((c) => {
    const matchSearch = !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.personality_tags?.some((t) => t.toLowerCase().includes(search.toLowerCase()));
    const matchCat = category === 'All' || (category === 'Featured' && c.is_featured) || c.personality_tags?.some((t) => t.toLowerCase() === category.toLowerCase());
    return matchSearch && matchCat;
  });

  async function startChat(characterId: string) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { data: chat } = await supabase.from('chats').insert({
      user_id: user.id, character_id: characterId, title: 'New Roleplay',
    }).select().single();
    if (chat) router.push(`/chat/${chat.id}`);
  }

  return (
    <div className="min-h-screen p-4 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-black text-white mb-2">
            <span className="gradient-text">Discover</span> Characters
          </h1>
          <p className="text-gray-400">Find your perfect AI companion from hundreds of unique personalities.</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name or personality..."
              className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:border-pink-500/50 transition-colors text-sm"
            />
          </div>
        </div>

        <div className="flex gap-2 flex-wrap mb-8">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                category === cat ? 'gradient-magenta text-white' : 'glass-card text-gray-400 hover:text-white'
              }`}
            >
              {cat === 'Featured' && <Sparkles className="w-3.5 h-3.5 inline mr-1" />}
              {cat}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <Sparkles className="w-12 h-12 text-gray-700 mx-auto mb-4" />
            <p className="text-gray-500">No characters found. Try a different search.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filtered.map((char) => (
              <div
                key={char.id}
                className="character-card glass-card rounded-2xl overflow-hidden border border-white/5 hover:border-pink-500/20"
              >
                <div className="relative h-48"
                  style={{ background: 'linear-gradient(160deg, #1a0525 0%, #0d0118 50%, #050505 100%)' }}>
                  <div className="absolute inset-0"
                    style={{ background: 'radial-gradient(circle at 50% 30%, rgba(192,38,211,0.25) 0%, transparent 60%)' }} />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-20 h-20 mx-auto rounded-full border-2 border-pink-500/40 flex items-center justify-center"
                        style={{ background: 'linear-gradient(135deg, #2d0845, #1a0530)', boxShadow: '0 0 20px rgba(192,38,211,0.4)' }}>
                        <span className="text-3xl font-black text-pink-400">{char.name[0]}</span>
                      </div>
                    </div>
                  </div>
                  {char.is_featured && (
                    <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-full gradient-magenta text-white text-xs">
                      <Sparkles className="w-2.5 h-2.5" />
                      Featured
                    </div>
                  )}
                  <div className="absolute bottom-0 left-0 right-0 h-12"
                    style={{ background: 'linear-gradient(to top, rgba(5,5,5,0.95), transparent)' }} />
                </div>

                <div className="p-4">
                  <h3 className="text-white font-bold mb-0.5">{char.name}</h3>
                  <p className="text-pink-400 text-xs mb-2">{char.species} • {char.gender} • {char.age}</p>

                  <p className="text-gray-400 text-xs leading-relaxed mb-3 line-clamp-2">
                    {char.personality || char.backstory || 'A unique AI companion.'}
                  </p>

                  <div className="flex flex-wrap gap-1 mb-3">
                    {char.personality_tags?.slice(0, 3).map((tag) => (
                      <span key={tag} className="px-1.5 py-0.5 rounded text-xs"
                        style={{ background: 'rgba(192,38,211,0.15)', color: '#F472B6', border: '1px solid rgba(192,38,211,0.2)' }}>
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <MessageCircle className="w-3 h-3" />
                        {char.chat_count?.toLocaleString() || '0'}
                      </span>
                      <span className="flex items-center gap-1">
                        <Heart className="w-3 h-3" />
                        {char.like_count?.toLocaleString() || '0'}
                      </span>
                    </div>
                    <button
                      onClick={() => startChat(char.id)}
                      className="text-xs font-semibold px-3 py-1.5 rounded-lg gradient-magenta text-white hover:opacity-90 transition-opacity"
                    >
                      Chat
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
