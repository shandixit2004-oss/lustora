'use client';

import Link from 'next/link';
import { MessageCircle, Heart, Sparkles, Lock } from 'lucide-react';
import { Character } from '@/types';

interface CharacterCardProps {
  character: Character;
  onChat?: () => void;
  compact?: boolean;
}

export default function CharacterCard({ character, onChat, compact = false }: CharacterCardProps) {
  const accentColors: Record<string, string> = {
    '#C026D3': 'rgba(192,38,211,0.3)',
    '#22D3EE': 'rgba(34,211,238,0.3)',
    '#F472B6': 'rgba(244,114,182,0.3)',
    '#F97316': 'rgba(249,115,22,0.3)',
  };

  const accent = '#C026D3';

  return (
    <div className={`character-card glass-card rounded-2xl overflow-hidden cursor-pointer border border-white/5 hover:border-pink-500/20 ${compact ? '' : ''}`}>
      <div className="relative" style={{ height: compact ? '140px' : '180px', background: 'linear-gradient(160deg, #1a0525 0%, #0d0118 50%, #050505 100%)' }}>
        <div className="absolute inset-0"
          style={{ background: `radial-gradient(circle at 50% 30%, ${accentColors[accent] || 'rgba(192,38,211,0.2)'} 0%, transparent 60%)` }} />

        {character.avatar_url ? (
          <img src={character.avatar_url} alt={character.name} className="w-full h-full object-cover" />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto rounded-full border-2 border-pink-500/40 flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, #2d0845, #1a0530)', boxShadow: '0 0 20px rgba(192,38,211,0.4)' }}>
                <span className="text-2xl font-black text-pink-400">{character.name[0]}</span>
              </div>
              <div className="mt-1 text-xs text-gray-500">{character.species}</div>
            </div>
          </div>
        )}

        {character.is_featured && (
          <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-full gradient-magenta text-white text-xs font-semibold">
            <Sparkles className="w-3 h-3" />
            Featured
          </div>
        )}

        {character.visibility === 'private' && (
          <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-gray-800/80 flex items-center justify-center">
            <Lock className="w-3 h-3 text-gray-400" />
          </div>
        )}

        <div className="absolute bottom-0 left-0 right-0 h-16"
          style={{ background: 'linear-gradient(to top, rgba(5,5,5,0.95), transparent)' }} />
      </div>

      <div className="p-4">
        <div className="flex items-start justify-between mb-1">
          <div>
            <h3 className="text-white font-bold text-sm">{character.name}</h3>
            <p className="text-pink-400 text-xs">{character.species} • {character.age}</p>
          </div>
        </div>

        {!compact && (
          <p className="text-gray-400 text-xs leading-relaxed mb-3 line-clamp-2">
            {character.personality || character.backstory || 'A mysterious AI companion waiting to meet you.'}
          </p>
        )}

        <div className="flex flex-wrap gap-1 mb-3">
          {character.personality_tags.slice(0, 3).map((tag) => (
            <span key={tag} className="px-1.5 py-0.5 rounded text-xs"
              style={{ background: 'rgba(192,38,211,0.15)', color: '#F472B6', border: '1px solid rgba(192,38,211,0.2)' }}>
              {tag}
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 text-xs text-gray-500">
            <span className="flex items-center gap-1">
              <MessageCircle className="w-3 h-3" />
              {character.chat_count.toLocaleString()}
            </span>
            <span className="flex items-center gap-1">
              <Heart className="w-3 h-3" />
              {character.like_count.toLocaleString()}
            </span>
          </div>
          <button
            onClick={onChat}
            className="text-xs font-semibold px-3 py-1.5 rounded-lg gradient-magenta text-white hover:opacity-90 transition-opacity"
          >
            Chat
          </button>
        </div>
      </div>
    </div>
  );
}
