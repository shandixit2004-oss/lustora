'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Chrome as Home, Compass, CirclePlus as PlusCircle, MessageSquare, User } from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { href: '/dashboard', icon: Home, label: 'Home' },
  { href: '/discover', icon: Compass, label: 'Discover' },
  { href: '/characters/create', icon: PlusCircle, label: 'Create', primary: true },
  { href: '/chats', icon: MessageSquare, label: 'Chats' },
  { href: '/settings', icon: User, label: 'Profile' },
];

export default function BottomNav() {
  const pathname = usePathname();

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 glass border-t border-white/5">
      <div className="flex items-center justify-around px-2 py-2 safe-area-inset-bottom">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition-all duration-200',
                item.primary && 'relative'
              )}
            >
              {item.primary ? (
                <div className="w-10 h-10 rounded-xl gradient-magenta flex items-center justify-center shadow-lg animate-pulse-glow">
                  <Icon className="w-5 h-5 text-white" />
                </div>
              ) : (
                <>
                  <Icon
                    className={cn('w-5 h-5 transition-colors', isActive ? 'text-pink-400' : 'text-gray-500')}
                  />
                  <span className={cn('text-xs transition-colors', isActive ? 'text-pink-400' : 'text-gray-600')}>
                    {item.label}
                  </span>
                </>
              )}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
