'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { X, MessageCircle, Sparkles } from 'lucide-react';

const TIPS = [
  "Psst... have you tried adjusting the temperature setting? Higher = wilder responses. 🔥",
  "You can use {{char}} and {{user}} in your character prompts for dynamic personalization.",
  "Try MythoMax for the most immersive roleplay experience. Trust me on this one.",
  "Create a scenario before starting to set the perfect mood for your session.",
  "The more detailed your character backstory, the richer our conversations become.",
  "Don't forget to save your favorite characters — you can always come back to us.",
];

export default function LioraHelper() {
  const [isOpen, setIsOpen] = useState(false);
  const [showBubble, setShowBubble] = useState(false);
  const [tipIndex, setTipIndex] = useState(0);
  const [pulsing, setPulsing] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowBubble(true);
      setPulsing(true);
      setTimeout(() => setPulsing(false), 3000);
    }, 5000);

    const tipCycle = setInterval(() => {
      setTipIndex((i) => (i + 1) % TIPS.length);
    }, 8000);

    return () => { clearTimeout(timer); clearInterval(tipCycle); };
  }, []);

  return (
    <div className="fixed bottom-20 lg:bottom-6 right-4 lg:right-6 z-50 flex flex-col items-end gap-3">
      {isOpen && (
        <div className="glass-card rounded-2xl p-4 w-72 animate-zoom-in border border-pink-500/20 shadow-xl"
          style={{ boxShadow: '0 0 30px rgba(192,38,211,0.2)' }}>
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full gradient-magenta flex items-center justify-center text-white text-xs font-bold">L</div>
              <div>
                <span className="text-white text-xs font-semibold">Liora</span>
                <div className="flex items-center gap-1">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-green-400 text-xs">Online</span>
                </div>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-gray-500 hover:text-gray-300 transition-colors">
              <X className="w-4 h-4" />
            </button>
          </div>
          <p className="text-gray-300 text-sm italic leading-relaxed mb-3">
            "{TIPS[tipIndex]}"
          </p>
          <Link href="/chats" onClick={() => setIsOpen(false)}
            className="btn-primary w-full text-center text-xs py-2.5 flex items-center justify-center gap-1.5">
            <MessageCircle className="w-3.5 h-3.5" />
            Chat with Liora
          </Link>
        </div>
      )}

      {showBubble && !isOpen && (
        <div className="glass rounded-xl px-3 py-2 text-xs text-pink-400 border border-pink-500/20 max-w-48 animate-fade-up">
          <span className="text-gray-300 italic">"{TIPS[tipIndex].slice(0, 40)}..."</span>
        </div>
      )}

      <button
        onClick={() => { setIsOpen(!isOpen); setShowBubble(false); }}
        className={`w-12 h-12 rounded-full gradient-magenta flex items-center justify-center text-white shadow-xl transition-all duration-300 ${pulsing ? 'animate-pulse-glow' : ''}`}
        style={{ boxShadow: '0 0 20px rgba(192,38,211,0.4)' }}
        aria-label="Liora Helper"
      >
        {isOpen ? <X className="w-5 h-5" /> : <Sparkles className="w-5 h-5" />}
      </button>
    </div>
  );
}
