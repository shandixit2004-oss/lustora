'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Chrome as Home, Compass, User, CirclePlus as PlusCircle, MessageSquare, Settings, LogOut, Sparkles, Crown } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { cn } from '@/lib/utils';

const navItems = [
  { href: '/dashboard', icon: Home, label: 'Home' },
  { href: '/discover', icon: Compass, label: 'Discover' },
  { href: '/characters', icon: User, label: 'My Characters' },
  { href: '/characters/create', icon: PlusCircle, label: 'Create' },
  { href: '/chats', icon: MessageSquare, label: 'Chats' },
];

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push('/');
  }

  return (
    <aside className="hidden lg:flex flex-col w-64 min-h-screen glass border-r border-white/5 fixed left-0 top-0 z-40">
      <div className="p-6 border-b border-white/5">
        <Link href="/dashboard" className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl gradient-magenta flex items-center justify-center text-white font-black animate-pulse-glow">
            L
          </div>
          <span className="text-xl font-black gradient-text">Lustora</span>
        </Link>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href || pathname.startsWith(item.href + '/');
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200',
                isActive
                  ? 'nav-item-active'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              )}
            >
              <Icon className={cn('w-4.5 h-4.5', isActive ? 'text-pink-400' : '')} style={{ width: '18px', height: '18px' }} />
              {item.label}
              {item.label === 'Create' && (
                <span className="ml-auto text-xs px-1.5 py-0.5 rounded-full"
                  style={{ background: 'rgba(192,38,211,0.2)', color: '#F472B6' }}>
                  New
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-white/5 space-y-2">
        <div className="glass-card rounded-xl p-4 mb-3">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-6 h-6 rounded-full gradient-magenta flex items-center justify-center">
              <Sparkles className="w-3 h-3 text-white" />
            </div>
            <span className="text-white text-xs font-semibold">100 Free Credits</span>
          </div>
          <div className="w-full h-1.5 rounded-full bg-white/10 mb-2">
            <div className="h-full rounded-full gradient-magenta" style={{ width: '40%' }} />
          </div>
          <p className="text-gray-500 text-xs">40 credits used today</p>
          <button className="mt-3 w-full flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold gradient-magenta text-white hover:opacity-90 transition-opacity">
            <Crown className="w-3 h-3" />
            Upgrade to Premium
          </button>
        </div>

        <Link
          href="/settings"
          className={cn(
            'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200',
            pathname === '/settings' ? 'nav-item-active' : 'text-gray-400 hover:text-white hover:bg-white/5'
          )}
        >
          <Settings style={{ width: '18px', height: '18px' }} />
          Settings
        </Link>

        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-400 hover:text-red-400 hover:bg-red-500/5 transition-all duration-200"
        >
          <LogOut style={{ width: '18px', height: '18px' }} />
          Sign Out
        </button>
      </div>
    </aside>
  );
}
