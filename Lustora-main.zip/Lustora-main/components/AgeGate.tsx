'use client';

import { useState, useEffect } from 'react';
import { Shield, TriangleAlert as AlertTriangle, X } from 'lucide-react';

export default function AgeGate() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const verified = localStorage.getItem('lustora_age_verified');
    if (!verified) setShow(true);
  }, []);

  function handleVerify() {
    localStorage.setItem('lustora_age_verified', 'true');
    setShow(false);
  }

  function handleDeny() {
    window.location.href = 'https://www.google.com';
  }

  if (!show) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center age-gate-overlay bg-black/95">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full opacity-20"
            style={{
              width: Math.random() * 4 + 2 + 'px',
              height: Math.random() * 4 + 2 + 'px',
              background: i % 2 === 0 ? '#C026D3' : '#F472B6',
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              animation: `particle-rise ${Math.random() * 10 + 8}s linear infinite`,
              animationDelay: Math.random() * 5 + 's',
            }}
          />
        ))}
      </div>

      <div className="relative max-w-md w-full mx-4">
        <div className="glass-card rounded-2xl p-8 text-center animate-zoom-in">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <div className="w-20 h-20 rounded-full gradient-magenta flex items-center justify-center animate-pulse-glow">
                <Shield className="w-10 h-10 text-white" />
              </div>
              <div className="absolute -top-1 -right-1 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">18+</span>
              </div>
            </div>
          </div>

          <div className="mb-2">
            <span className="gradient-text text-3xl font-black tracking-tight">LUSTORA</span>
          </div>

          <div className="flex items-center justify-center gap-2 mb-6 text-yellow-400">
            <AlertTriangle className="w-4 h-4" />
            <span className="text-sm font-semibold">Adult Content Warning</span>
          </div>

          <p className="text-gray-300 text-sm leading-relaxed mb-2">
            This platform contains <strong className="text-pink-400">explicit adult content</strong> including mature themes, suggestive roleplay, and NSFW AI-generated scenarios.
          </p>
          <p className="text-gray-400 text-sm mb-8">
            By entering, you confirm you are <strong className="text-white">18 years of age or older</strong> and consent to viewing adult content.
          </p>

          <div className="space-y-3">
            <button
              onClick={handleVerify}
              className="btn-primary w-full text-base py-3.5"
            >
              I am 18 or older — Enter
            </button>
            <button
              onClick={handleDeny}
              className="w-full py-3 text-gray-500 hover:text-gray-300 text-sm transition-colors"
            >
              I am under 18 — Exit
            </button>
          </div>

          <p className="text-gray-600 text-xs mt-6">
            By entering, you agree to our Terms of Service and Privacy Policy. All AI characters are fictional. All users must be 18+.
          </p>
        </div>
      </div>
    </div>
  );
}
