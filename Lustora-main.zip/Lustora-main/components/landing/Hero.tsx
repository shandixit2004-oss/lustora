'use client';

import Link from 'next/link';
import { Sparkles, ChevronRight, Play, Star } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full opacity-20"
          style={{ background: 'radial-gradient(circle, #C026D3 0%, transparent 70%)', filter: 'blur(60px)' }} />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full opacity-15"
          style={{ background: 'radial-gradient(circle, #F472B6 0%, transparent 70%)', filter: 'blur(60px)' }} />
        <div className="absolute top-1/2 right-1/3 w-64 h-64 rounded-full opacity-10"
          style={{ background: 'radial-gradient(circle, #22D3EE 0%, transparent 70%)', filter: 'blur(60px)' }} />
        {[...Array(30)].map((_, i) => (
          <div key={i} className="absolute rounded-full"
            style={{
              width: Math.random() * 3 + 1 + 'px',
              height: Math.random() * 3 + 1 + 'px',
              background: ['#C026D3', '#F472B6', '#22D3EE'][i % 3],
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              opacity: Math.random() * 0.5 + 0.2,
              animation: `particle-rise ${Math.random() * 15 + 10}s linear infinite`,
              animationDelay: Math.random() * 8 + 's',
            }} />
        ))}
      </div>

      <div className="container mx-auto px-4 lg:px-8 pt-24 pb-16 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-fade-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-pink-500/20 text-pink-400 text-sm">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Next-gen AI Roleplay Platform</span>
              <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              <span className="text-green-400 text-xs">Live</span>
            </div>

            <div>
              <h1 className="text-6xl md:text-7xl lg:text-8xl font-black leading-none tracking-tight mb-4">
                <span className="text-white">Bring Your</span>
                <br />
                <span className="gradient-text text-glow-pink">Fantasies</span>
                <br />
                <span className="text-white">to Life</span>
              </h1>
              <p className="text-xl text-gray-400 leading-relaxed max-w-xl">
                Immersive AI companions that <strong className="text-pink-400">remember everything</strong>, feel everything, and exist only for you. Uncensored. Unlimited. Yours.
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              <Link href="/signup" className="btn-primary flex items-center gap-2 text-lg px-8 py-4">
                <Sparkles className="w-5 h-5" />
                Start Free
                <ChevronRight className="w-4 h-4" />
              </Link>
              <Link href="/discover" className="btn-secondary flex items-center gap-2 text-lg px-8 py-4">
                <Play className="w-4 h-4" />
                Browse Characters
              </Link>
            </div>

            <div className="flex items-center gap-8 pt-4">
              <div className="flex flex-col">
                <span className="text-3xl font-black gradient-text-pink">50K+</span>
                <span className="text-gray-500 text-sm">Active Users</span>
              </div>
              <div className="w-px h-10 bg-gray-800" />
              <div className="flex flex-col">
                <span className="text-3xl font-black gradient-text-pink">2M+</span>
                <span className="text-gray-500 text-sm">Conversations</span>
              </div>
              <div className="w-px h-10 bg-gray-800" />
              <div className="flex flex-col">
                <span className="text-3xl font-black gradient-text-pink">500+</span>
                <span className="text-gray-500 text-sm">Characters</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex -space-x-2">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="w-8 h-8 rounded-full border-2 border-[#050505] gradient-magenta flex items-center justify-center text-white text-xs font-bold">
                    {['A', 'K', 'S', 'M', 'R'][i]}
                  </div>
                ))}
              </div>
              <div className="flex items-center gap-1 text-yellow-400">
                {[...Array(5)].map((_, i) => <Star key={i} className="w-3.5 h-3.5 fill-current" />)}
              </div>
              <span className="text-gray-400 text-sm">Loved by thousands</span>
            </div>
          </div>

          <div className="relative flex justify-center items-center" style={{ animationDelay: '0.2s' }}>
            <div className="relative w-full max-w-md">
              <div className="absolute inset-0 rounded-3xl opacity-30"
                style={{ background: 'radial-gradient(circle at center, #C026D3 0%, transparent 70%)', filter: 'blur(40px)' }} />
              <div className="relative rounded-3xl overflow-hidden border border-pink-500/20 shadow-2xl"
                style={{ boxShadow: '0 0 60px rgba(192,38,211,0.3), 0 0 120px rgba(192,38,211,0.1)' }}>
                <div className="aspect-[3/4] relative"
                  style={{ background: 'linear-gradient(160deg, #1a0525 0%, #0d0118 30%, #050505 60%, #0d0118 100%)' }}>
                  <div className="absolute inset-0 flex items-end justify-center pb-0">
                    <div className="w-full h-full relative">
                      <div className="absolute inset-0"
                        style={{ background: 'radial-gradient(ellipse at 50% 30%, rgba(192,38,211,0.3) 0%, transparent 60%)' }} />
                      <div className="absolute bottom-0 left-0 right-0 h-2/3 flex items-end justify-center">
                        <div className="relative w-72 h-full">
                          <div className="absolute bottom-0 w-full h-full rounded-2xl overflow-hidden">
                            <div className="w-full h-full"
                              style={{ background: 'linear-gradient(180deg, transparent 0%, rgba(192,38,211,0.05) 50%, rgba(244,114,182,0.08) 100%)' }} />
                          </div>
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="text-center space-y-4 animate-float">
                              <div className="w-32 h-32 mx-auto rounded-full relative"
                                style={{ background: 'linear-gradient(135deg, rgba(192,38,211,0.6) 0%, rgba(244,114,182,0.4) 100%)', boxShadow: '0 0 40px rgba(192,38,211,0.6)' }}>
                                <div className="absolute inset-0 flex items-center justify-center text-6xl select-none">
                                  <div className="w-28 h-28 rounded-full overflow-hidden border-2 border-pink-400/50"
                                    style={{ background: 'linear-gradient(135deg, #2d0845 0%, #1a0530 100%)' }}>
                                    <div className="w-full h-full flex items-center justify-center">
                                      <div className="relative">
                                        <div className="w-20 h-20 rounded-full"
                                          style={{ background: 'linear-gradient(135deg, #f9c8e8 0%, #e8a0d0 50%, #d060c0 100%)' }} />
                                        <div className="absolute -top-2 left-1/2 -translate-x-1/2 flex gap-3">
                                          <div className="w-1.5 h-4 rounded-full"
                                            style={{ background: '#C026D3', transform: 'rotate(-15deg)', boxShadow: '0 0 8px #C026D3' }} />
                                          <div className="w-1.5 h-4 rounded-full"
                                            style={{ background: '#C026D3', transform: 'rotate(15deg)', boxShadow: '0 0 8px #C026D3' }} />
                                        </div>
                                        <div className="absolute top-6 left-1/2 -translate-x-1/2 flex gap-3">
                                          <div className="w-3 h-2 rounded-full"
                                            style={{ background: '#F472B6', boxShadow: '0 0 6px #F472B6' }} />
                                          <div className="w-3 h-2 rounded-full"
                                            style={{ background: '#F472B6', boxShadow: '0 0 6px #F472B6' }} />
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div>
                                <div className="text-white font-bold text-xl text-glow-pink">Liora Voss</div>
                                <div className="text-pink-400 text-sm">Platform Companion</div>
                                <div className="flex items-center justify-center gap-1.5 mt-1">
                                  <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                                  <span className="text-green-400 text-xs">Online Now</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="absolute bottom-6 left-6 right-6">
                    <div className="glass rounded-2xl p-4 border border-pink-500/20">
                      <p className="text-gray-300 text-sm italic leading-relaxed">
                        <span className="text-pink-400">*</span>glances at you with glowing eyes<span className="text-pink-400">*</span> "I've been waiting for you, darling..."
                      </p>
                      <div className="mt-3 flex items-center gap-2">
                        <div className="flex gap-1">
                          <div className="w-2 h-2 rounded-full bg-pink-400 typing-dot" />
                          <div className="w-2 h-2 rounded-full bg-pink-400 typing-dot" />
                          <div className="w-2 h-2 rounded-full bg-pink-400 typing-dot" />
                        </div>
                        <span className="text-gray-500 text-xs">Liora is typing...</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="absolute -top-4 -right-4 glass rounded-xl p-3 border border-pink-500/20 animate-float" style={{ animationDelay: '1s' }}>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full gradient-magenta flex items-center justify-center text-white text-xs">✦</div>
                  <div>
                    <div className="text-white text-xs font-semibold">Memory Active</div>
                    <div className="text-gray-500 text-xs">Remembers everything</div>
                  </div>
                </div>
              </div>

              <div className="absolute -bottom-4 -left-4 glass rounded-xl p-3 border border-cyan-500/20 animate-float" style={{ animationDelay: '2s' }}>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 text-xs">∞</div>
                  <div>
                    <div className="text-white text-xs font-semibold">Uncensored</div>
                    <div className="text-gray-500 text-xs">No restrictions</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
