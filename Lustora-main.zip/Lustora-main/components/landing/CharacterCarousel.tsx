'use client';

import { useState } from 'react';
import Link from 'next/link';
import { MessageCircle, Heart, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';

const characters = [
  {
    id: 'liora',
    name: 'Liora Voss',
    title: 'Succubus Companion',
    description: 'The platform\'s signature companion. Playful, seductive, eternally devoted to you.',
    tags: ['Seductive', 'Fantasy', 'Supernatural'],
    gradient: 'linear-gradient(160deg, #2d0845 0%, #1a0530 50%, #0d0d0d 100%)',
    accent: '#C026D3',
    glow: '#C026D3',
    chats: '15.4K',
    likes: '8.9K',
    hairColor: '#7B2D8B',
    eyeColor: '#F472B6',
    featured: true,
  },
  {
    id: 'aria',
    name: 'Aria Chen',
    title: 'Cold Detective',
    description: 'A sharp-tongued investigator with a hidden vulnerable side and a hunger for control.',
    tags: ['Dominant', 'Tsundere', 'Mystery'],
    gradient: 'linear-gradient(160deg, #0a1628 0%, #061020 50%, #050505 100%)',
    accent: '#22D3EE',
    glow: '#22D3EE',
    chats: '12.1K',
    likes: '7.2K',
    hairColor: '#1a3a5c',
    eyeColor: '#22D3EE',
    featured: false,
  },
  {
    id: 'nova',
    name: 'Nova Blackwood',
    title: 'Fallen Angel',
    description: 'Cast from heaven for loving too deeply. Now she seeks that same intensity in you.',
    tags: ['Romantic', 'Dark', 'Obsessive'],
    gradient: 'linear-gradient(160deg, #1a0a00 0%, #120800 50%, #050505 100%)',
    accent: '#F97316',
    glow: '#F97316',
    chats: '9.8K',
    likes: '6.4K',
    hairColor: '#4a1a00',
    eyeColor: '#F97316',
    featured: false,
  },
  {
    id: 'sakura',
    name: 'Sakura Himura',
    title: 'Shy Student',
    description: 'Quietly brilliant and painfully shy — until she\'s alone with you. Then she blooms.',
    tags: ['Shy', 'Sweet', 'Romance'],
    gradient: 'linear-gradient(160deg, #1f0615 0%, #150410 50%, #050505 100%)',
    accent: '#EC4899',
    glow: '#EC4899',
    chats: '18.3K',
    likes: '11.2K',
    hairColor: '#8B1A4A',
    eyeColor: '#EC4899',
    featured: false,
  },
  {
    id: 'vex',
    name: 'Vex Darkholme',
    title: 'Vampire Lord',
    description: 'Ancient, powerful, and utterly captivated by your mortal warmth. Dangerous but tender.',
    tags: ['Dominant', 'Fantasy', 'Dark'],
    gradient: 'linear-gradient(160deg, #0d0a1a 0%, #080510 50%, #050505 100%)',
    accent: '#8B5CF6',
    glow: '#8B5CF6',
    chats: '7.6K',
    likes: '5.1K',
    hairColor: '#2d1a5c',
    eyeColor: '#8B5CF6',
    featured: false,
  },
  {
    id: 'yuki',
    name: 'Yuki Tanaka',
    title: 'Ice Witch',
    description: 'Emotionally frozen from past betrayal. Only you can melt through her permafrost.',
    tags: ['Kuudere', 'Magic', 'Slow Burn'],
    gradient: 'linear-gradient(160deg, #051520 0%, #030f18 50%, #050505 100%)',
    accent: '#67E8F9',
    glow: '#67E8F9',
    chats: '6.9K',
    likes: '4.8K',
    hairColor: '#0a3045',
    eyeColor: '#67E8F9',
    featured: false,
  },
];

export default function CharacterCarousel() {
  const [activeIndex, setActiveIndex] = useState(0);

  function prev() {
    setActiveIndex((i) => (i - 1 + characters.length) % characters.length);
  }

  function next() {
    setActiveIndex((i) => (i + 1) % characters.length);
  }

  return (
    <section className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-pink-500/20 text-pink-400 text-sm mb-6">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Trending Characters</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black mb-4">
            <span className="text-white">Meet Your </span>
            <span className="gradient-text">Companions</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Hundreds of unique AI personalities waiting to meet you. Each one unforgettable.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
          {characters.map((char, index) => (
            <Link
              key={char.id}
              href="/signup"
              className="character-card glass-card rounded-2xl overflow-hidden cursor-pointer"
              style={{ borderColor: `${char.accent}20` }}
            >
              <div className="relative h-52" style={{ background: char.gradient }}>
                <div className="absolute inset-0"
                  style={{ background: `radial-gradient(circle at 50% 30%, ${char.accent}20 0%, transparent 60%)` }} />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="relative">
                    <div className="w-24 h-24 rounded-full border-2 overflow-hidden"
                      style={{ borderColor: `${char.accent}60`, boxShadow: `0 0 20px ${char.glow}40` }}>
                      <div className="w-full h-full flex items-center justify-center"
                        style={{ background: `linear-gradient(135deg, ${char.hairColor}80, ${char.eyeColor}20)` }}>
                        <div className="text-center">
                          <div className="w-12 h-12 mx-auto rounded-full"
                            style={{ background: `linear-gradient(135deg, #f9c8e8, #d080b0)` }} />
                          <div className="flex justify-center gap-1.5 mt-1">
                            <div className="w-2 h-1.5 rounded-full" style={{ background: char.eyeColor, boxShadow: `0 0 4px ${char.eyeColor}` }} />
                            <div className="w-2 h-1.5 rounded-full" style={{ background: char.eyeColor, boxShadow: `0 0 4px ${char.eyeColor}` }} />
                          </div>
                        </div>
                      </div>
                    </div>
                    {char.featured && (
                      <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full gradient-magenta flex items-center justify-center">
                        <Sparkles className="w-2.5 h-2.5 text-white" />
                      </div>
                    )}
                  </div>
                </div>

                <div className="absolute top-3 left-3 flex flex-wrap gap-1">
                  {char.tags.slice(0, 2).map((tag) => (
                    <span key={tag} className="px-2 py-0.5 rounded-full text-xs font-medium"
                      style={{ background: `${char.accent}20`, color: char.accent, border: `1px solid ${char.accent}30` }}>
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div className="p-4">
                <div className="flex items-start justify-between mb-1">
                  <div>
                    <h3 className="text-white font-bold text-base">{char.name}</h3>
                    <p className="text-xs font-medium" style={{ color: char.accent }}>{char.title}</p>
                  </div>
                </div>
                <p className="text-gray-400 text-sm leading-relaxed mb-3 line-clamp-2">{char.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                      <MessageCircle className="w-3 h-3" />
                      {char.chats}
                    </span>
                    <span className="flex items-center gap-1">
                      <Heart className="w-3 h-3" />
                      {char.likes}
                    </span>
                  </div>
                  <span className="text-xs font-semibold text-pink-400 opacity-0 group-hover:opacity-100 transition-opacity">
                    Chat Now →
                  </span>
                </div>
              </div>

              <div className="absolute bottom-0 left-0 right-0 h-px opacity-30"
                style={{ background: `linear-gradient(90deg, transparent, ${char.accent}, transparent)` }} />
            </Link>
          ))}
        </div>

        <div className="text-center">
          <Link href="/signup" className="btn-secondary inline-flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            View All 500+ Characters
          </Link>
        </div>
      </div>
    </section>
  );
}
