import Link from 'next/link';
import { Shield, Heart, ExternalLink } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-white/5 py-16 relative">
      <div className="neon-line absolute top-0 left-0 right-0" />
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg gradient-magenta flex items-center justify-center text-white font-black text-sm">L</div>
              <span className="text-2xl font-black gradient-text">Lustora</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed max-w-sm mb-6">
              Premium AI roleplay platform. Create deep, meaningful connections with AI companions that truly understand you.
            </p>
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg glass border border-yellow-500/20 w-fit">
              <Shield className="w-4 h-4 text-yellow-400" />
              <span className="text-yellow-400 text-xs font-semibold">18+ Platform — Adults Only</span>
            </div>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4 text-sm">Platform</h4>
            <ul className="space-y-2.5">
              {['Discover', 'Create Character', 'Browse Models', 'Pricing'].map((item) => (
                <li key={item}>
                  <Link href="/signup" className="text-gray-400 hover:text-pink-400 text-sm transition-colors">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4 text-sm">Legal</h4>
            <ul className="space-y-2.5">
              {[
                { label: 'Terms of Service', href: '#' },
                { label: 'Privacy Policy', href: '#' },
                { label: 'Content Policy', href: '#' },
                { label: 'Age Verification', href: '#' },
                { label: 'DMCA', href: '#' },
              ].map((item) => (
                <li key={item.label}>
                  <Link href={item.href} className="text-gray-400 hover:text-pink-400 text-sm transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-gray-600 text-xs text-center md:text-left">
            © 2026 Lustora. All rights reserved. All characters are fictional. For adults 18+ only.
            <br />
            All AI-generated content is fictional and for entertainment purposes only.
          </div>
          <div className="flex items-center gap-1 text-gray-600 text-xs">
            <span>Made with</span>
            <Heart className="w-3 h-3 text-pink-500 fill-current" />
            <span>for fantasy</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
