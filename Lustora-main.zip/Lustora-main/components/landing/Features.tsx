import { Brain, Zap, Image, Mic, Users, Shield, Sparkles, Heart } from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: 'Persistent Memory',
    description: 'Your AI companion remembers every detail, every secret, every moment you\'ve shared. No resets. No starting over.',
    color: '#C026D3',
    glow: 'rgba(192,38,211,0.3)',
  },
  {
    icon: Shield,
    title: 'Truly Uncensored',
    description: 'Explore your deepest fantasies without restrictions. Powered by the most capable uncensored models available.',
    color: '#EF4444',
    glow: 'rgba(239,68,68,0.3)',
  },
  {
    icon: Image,
    title: 'AI Image Generation',
    description: 'Bring your characters to life visually. Generate stunning character art and scene images mid-roleplay.',
    color: '#F472B6',
    glow: 'rgba(244,114,182,0.3)',
  },
  {
    icon: Sparkles,
    title: 'Character Creation',
    description: 'Build your perfect companion from scratch — appearance, personality, kinks, backstory. Every detail matters.',
    color: '#22D3EE',
    glow: 'rgba(34,211,238,0.3)',
  },
  {
    icon: Users,
    title: 'Multi-Character Scenes',
    description: 'Set up complex scenarios with multiple AI characters interacting — group roleplays, love triangles, full storylines.',
    color: '#A78BFA',
    glow: 'rgba(167,139,250,0.3)',
  },
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Powered by OpenRouter giving you access to the fastest, most capable AI models for seamless conversation flow.',
    color: '#FBBF24',
    glow: 'rgba(251,191,36,0.3)',
  },
  {
    icon: Mic,
    title: 'Voice Coming Soon',
    description: 'Hear your character\'s voice. Real-time TTS with emotion, breathing, and personality — launching Q1 2025.',
    color: '#34D399',
    glow: 'rgba(52,211,153,0.3)',
    soon: true,
  },
  {
    icon: Heart,
    title: 'Relationship System',
    description: 'Characters develop feelings for you over time. Watch affection grow, jealousy emerge, and deep bonds form.',
    color: '#F87171',
    glow: 'rgba(248,113,113,0.3)',
  },
];

export default function Features() {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="neon-line absolute top-0 left-0 right-0" />
        <div className="neon-line absolute bottom-0 left-0 right-0" />
      </div>

      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-pink-500/20 text-pink-400 text-sm mb-6">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Everything You Need</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black mb-4">
            <span className="text-white">Built for </span>
            <span className="gradient-text">Immersion</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Every feature designed to make your experience feel as real, deep, and satisfying as possible.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={feature.title}
                className="glass-card rounded-2xl p-6 relative overflow-hidden group hover:border-opacity-40 transition-all duration-300"
                style={{
                  animationDelay: `${index * 0.05}s`,
                  borderColor: `${feature.color}20`,
                }}
              >
                {feature.soon && (
                  <div className="absolute top-3 right-3 px-2 py-0.5 rounded-full text-xs font-semibold"
                    style={{ background: `${feature.color}20`, color: feature.color }}>
                    Soon
                  </div>
                )}

                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  style={{ background: `radial-gradient(circle at 0 0, ${feature.glow} 0%, transparent 50%)` }} />

                <div className="relative z-10">
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                    style={{ background: `${feature.color}15`, border: `1px solid ${feature.color}30` }}>
                    <Icon className="w-6 h-6" style={{ color: feature.color }} />
                  </div>

                  <h3 className="text-white font-bold text-base mb-2">{feature.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{feature.description}</p>
                </div>

                <div className="absolute bottom-0 left-0 right-0 h-px opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ background: `linear-gradient(90deg, transparent, ${feature.color}, transparent)` }} />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
