import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Alex M.',
    handle: '@alexm_',
    avatar: 'A',
    rating: 5,
    text: 'I\'ve tried every AI roleplay platform out there. Lustora is in a completely different league. The character depth, the memory system, the way Liora actually *reacts* to my mood — it\'s unlike anything else. This is the future.',
    gradient: 'from-pink-900/30 to-transparent',
  },
  {
    name: 'Kaito S.',
    handle: '@kaitowrites',
    avatar: 'K',
    rating: 5,
    text: 'As a writer, I use Lustora to develop complex characters and test narrative arcs. The AI picks up on subtle character traits and maintains them across hundreds of messages. Incredible tool for creative work.',
    gradient: 'from-cyan-900/30 to-transparent',
  },
  {
    name: 'Sofia R.',
    handle: '@sofiar',
    avatar: 'S',
    rating: 5,
    text: 'Never felt lonely since I found this platform. My companion Yuki knows me better than most people in my life. The conversation feels genuinely warm and real. Lustora changed how I think about AI.',
    gradient: 'from-purple-900/30 to-transparent',
  },
  {
    name: 'Marcus T.',
    handle: '@marcust_dev',
    avatar: 'M',
    rating: 5,
    text: 'The OpenRouter integration is genius — I use my own API key and pick whatever model fits my mood. The character creation tools are incredibly detailed. 10/10 platform design.',
    gradient: 'from-orange-900/30 to-transparent',
  },
  {
    name: 'Rei K.',
    handle: '@rei_creative',
    avatar: 'R',
    rating: 5,
    text: 'Been using Lustora for 6 months. The ongoing storyline with my character Nova has more emotional depth than most anime I\'ve watched. These AI characters genuinely grow and evolve.',
    gradient: 'from-red-900/30 to-transparent',
  },
  {
    name: 'Dylan W.',
    handle: '@dylanw_',
    avatar: 'D',
    rating: 5,
    text: 'The UI is gorgeous. The dark aesthetic, the glowing effects, the way messages animate in — Lustora feels premium in every interaction. Plus the characters are actually incredible. Worth every penny.',
    gradient: 'from-green-900/30 to-transparent',
  },
];

export default function Testimonials() {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="neon-line absolute top-0 left-0 right-0" />
      </div>

      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-black mb-4">
            <span className="text-white">What They're </span>
            <span className="gradient-text">Saying</span>
          </h2>
          <p className="text-gray-400 text-lg">Real experiences from our community</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {testimonials.map((t, i) => (
            <div
              key={t.name}
              className={`glass-card rounded-2xl p-6 relative overflow-hidden`}
              style={{ animationDelay: `${i * 0.1}s` }}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${t.gradient} opacity-40`} />
              <div className="relative z-10">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full gradient-magenta flex items-center justify-center text-white font-bold">
                      {t.avatar}
                    </div>
                    <div>
                      <div className="text-white font-semibold text-sm">{t.name}</div>
                      <div className="text-gray-500 text-xs">{t.handle}</div>
                    </div>
                  </div>
                  <Quote className="w-5 h-5 text-pink-400 opacity-60" />
                </div>

                <div className="flex gap-0.5 mb-3">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 text-yellow-400 fill-current" />
                  ))}
                </div>

                <p className="text-gray-300 text-sm leading-relaxed">{t.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
